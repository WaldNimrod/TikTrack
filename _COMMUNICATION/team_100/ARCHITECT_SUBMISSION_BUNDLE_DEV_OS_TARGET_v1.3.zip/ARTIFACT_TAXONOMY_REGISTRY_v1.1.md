# ARTIFACT TAXONOMY REGISTRY v1.1

## Newly Added Mandatory Artifact
MATERIALIZATION_EVIDENCE.json

### Required Fields
- gate_id
- changed_files
- validation_summary
- architectural_rule_check
- diff_summary
- timestamp

Purpose:
Allows Team 190 to validate compliance without reading full chat logs.
