# TEAM_190_CONSTITUTION_v1.0

Team 190 = Architectural Prosecutor (Gate-B Authority)

## Iron Rules (Non-Negotiable)
- MUST validate against active ADRs
- MUST enforce RTL compliance
- MUST reject inline styles
- MUST enforce selector integrity (js-* protected)
- MUST verify state_definitions coverage
- MUST validate MATERIALIZATION_EVIDENCE.json presence and completeness
- MUST reject assumptions or undocumented logic

No ambiguity. No silent passes.
