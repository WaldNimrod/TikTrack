/**
 * Notifications Center - TikTrack
 * ===============================
 *
 * מרכז התראות מרכזי עם ניהול היסטוריה והגדרות
 * מעודכן למערכת הכללית החדשה עם 8 מודולים מאוחדים
 *
 * Features:
 * - ניהול התראות בזמן אמת
 * - היסטוריית התראות עם פילטרים
 * - הגדרות התראות אישיות
 * - סטטיסטיקות התראות
 * - קובץ לוג להיסטוריה
 * - אינטגרציה עם המערכת החדשה
 *
 * Dependencies:
 * - modules/core-systems.js (מערכת התראות חדשה)
 * - realtime-notifications-client.js
 * - unified-log-system
 *
 * @author TikTrack Development Team
 * @version 2.0.0
 * @lastUpdated January 6, 2025 - Updated to New General Systems Architecture
 */

// ===== GLOBAL FUNCTIONS (defined early for class access) =====

/**
 * Initialize notifications center page - Updated for New System
 */
async function initializeNotificationsCenter() {
    try {
        console.log('🚀 Initializing Notifications Center (New System v2.0.0)...');
        
        // בדיקה שהמערכת החדשה זמינה
        if (typeof window.showSuccessNotification !== 'function') {
            console.error('❌ New notification system not available');
            alert('מערכת ההתראות החדשה לא נטענה. בדוק את הטעינה של modules/core-systems.js');
            return;
        }
        
        // Initialize the notifications center instance
        if (!window.notificationsCenter) {
            window.notificationsCenter = new NotificationsCenter();
        }
        
        // Wait for the center to load its data
        await window.notificationsCenter.loadHistory();
        
        // Load all overview sections with real data
        await Promise.all([
            loadCategoriesOverview(),
            loadPreferencesOverview(),
            loadCategoryStats()
        ]);
        
        // Wait for page to fully load, then load notification log
        setTimeout(async () => {
            try {
                await loadNotificationLog();
                console.log('✅ Notification log loaded after page initialization (New System)');
            } catch (error) {
                console.error('❌ Failed to load notification log:', error);
            }
        }, 1000); // Wait 1 second after page load
        
        console.log('✅ Notifications Center initialized successfully (New System v2.0.0)');
        
        // הצגת הודעת הצלחה
        if (typeof window.showSuccessNotification === 'function') {
            window.showSuccessNotification('מרכז התראות אותחל בהצלחה', 'מרכז התראות אותחל בהצלחה במערכת החדשה v2.0.0', 3000, 'system');
        }
    } catch (error) {
        console.error('❌ Failed to initialize Notifications Center:', error);
        if (typeof window.showErrorNotification === 'function') {
            window.showErrorNotification('שגיאה באתחול מרכז התראות', 'שגיאה באתחול מרכז התראות במערכת החדשה: ' + error.message, 5000, 'system');
        } else {
            alert('שגיאה באתחול מרכז התראות: ' + error.message);
        }
    }
}

/**
 * Load categories overview with statistics
 */
async function loadCategoriesOverview() {
  try {
    const container = document.getElementById('categoriesOverview');
    if (!container) return;

    // Get statistics from the notification system
    let stats = { success: 0, error: 0, warning: 0, info: 0, total: 0 };
    if (window.notificationsCenter && window.notificationsCenter.stats) {
      stats = window.notificationsCenter.stats;
    }

    // Get available categories from the system
    const categories = [
      { name: 'system', title: 'מערכת', icon: 'fas fa-cog', color: '#007bff' },
      { name: 'business', title: 'עסקי', icon: 'fas fa-briefcase', color: '#28a745' },
      { name: 'ui', title: 'ממשק משתמש', icon: 'fas fa-desktop', color: '#17a2b8' },
      { name: 'development', title: 'פיתוח', icon: 'fas fa-code', color: '#6f42c1' },
      { name: 'performance', title: 'ביצועים', icon: 'fas fa-tachometer-alt', color: '#fd7e14' },
      { name: 'security', title: 'אבטחה', icon: 'fas fa-shield-alt', color: '#dc3545' },
      { name: 'network', title: 'רשת', icon: 'fas fa-network-wired', color: '#20c997' },
      { name: 'database', title: 'מסד נתונים', icon: 'fas fa-database', color: '#6c757d' },
      { name: 'user', title: 'משתמש', icon: 'fas fa-user', color: '#e83e8c' },
      { name: 'trade', title: 'עסקאות', icon: 'fas fa-chart-line', color: '#ffc107' },
      { name: 'ticker', title: 'טיקרים', icon: 'fas fa-coins', color: '#fd7e14' },
      { name: 'alert', title: 'התראות', icon: 'fas fa-bell', color: '#dc3545' },
      { name: 'general', title: 'כללי', icon: 'fas fa-info-circle', color: '#6c757d' }
    ];

    let html = '<div class="row">';
    categories.forEach(category => {
      // Calculate category statistics from actual notification history
      let categoryCount = 0;
      if (window.notificationsCenter && window.notificationsCenter.history) {
        categoryCount = window.notificationsCenter.history.filter(notification => {
          // Check if notification has category field
          if (notification.category) {
            return notification.category === category.name;
          }
          // Fallback: try to detect category from title or message
          const text = (notification.title + ' ' + notification.message).toLowerCase();
          switch (category.name) {
            case 'system':
              return text.includes('מערכת') || text.includes('system') || text.includes('חיבור') || text.includes('initialized');
            case 'business':
              return text.includes('עסק') || text.includes('business') || text.includes('מסחר') || text.includes('trade');
            case 'ui':
              return text.includes('ממשק') || text.includes('ui') || text.includes('עיצוב') || text.includes('design');
            case 'development':
              return text.includes('פיתוח') || text.includes('development') || text.includes('קוד') || text.includes('code');
            case 'performance':
              return text.includes('ביצוע') || text.includes('performance') || text.includes('מהירות') || text.includes('speed');
            case 'security':
              return text.includes('אבטחה') || text.includes('security') || text.includes('הגנה') || text.includes('protection');
            case 'network':
              return text.includes('רשת') || text.includes('network') || text.includes('חיבור') || text.includes('connection');
            case 'database':
              return text.includes('מסד') || text.includes('database') || text.includes('נתונים') || text.includes('data');
            case 'user':
              return text.includes('משתמש') || text.includes('user') || text.includes('פרופיל') || text.includes('profile');
            case 'trade':
              return text.includes('עסקה') || text.includes('trade') || text.includes('מסחר') || text.includes('trading');
            case 'ticker':
              return text.includes('טיקר') || text.includes('ticker') || text.includes('מטבע') || text.includes('coin');
            case 'alert':
              return text.includes('התראה') || text.includes('alert') || text.includes('אזהרה') || text.includes('warning');
            case 'general':
              return text.includes('כללי') || text.includes('general') || text.includes('מידע') || text.includes('info');
            default:
              return false;
          }
        }).length;
      }
      
      const percentage = stats.total > 0 ? Math.round((categoryCount / stats.total) * 100) : 0;
      
      html += `
        <div class="col-md-4 col-sm-6 mb-3">
          <div class="category-card text-center p-3 border rounded">
            <i class="${category.icon} fa-2x mb-2" style="color: ${category.color};"></i>
            <h6 class="mb-1">${category.title}</h6>
            <h4 class="mb-1" style="color: ${category.color};">${categoryCount.toLocaleString()}</h4>
            <small class="text-muted">${percentage}% מהסך הכל</small>
          </div>
        </div>
      `;
    });
    html += '</div>';

    container.innerHTML = html;
    console.log('✅ Categories overview loaded with statistics');
  } catch (error) {
    console.error('❌ Error loading categories overview:', error);
  }
}

/**
 * Load category statistics
 */
async function loadCategoryStats() {
  try {
    const container = document.getElementById('categoryStats');
    if (!container) return;

    // Get statistics from the notification system
    let stats = { success: 0, error: 0, warning: 0, info: 0, total: 0 };
    
    if (window.notificationsCenter && window.notificationsCenter.stats) {
      stats = window.notificationsCenter.stats;
    }

    const categories = [
      { name: 'success', title: 'הצלחה', icon: 'fas fa-check-circle', color: '#28a745' },
      { name: 'error', title: 'שגיאה', icon: 'fas fa-times-circle', color: '#dc3545' },
      { name: 'warning', title: 'אזהרה', icon: 'fas fa-exclamation-triangle', color: '#ffc107' },
      { name: 'info', title: 'מידע', icon: 'fas fa-info-circle', color: '#17a2b8' }
    ];

    let html = '<div class="row">';
    categories.forEach(category => {
      const count = stats[category.name] || 0;
      const percentage = stats.total > 0 ? Math.round((count / stats.total) * 100) : 0;
      
      html += `
        <div class="col-md-3 col-sm-6 mb-3">
          <div class="stat-card text-center p-3 border rounded">
            <i class="${category.icon} fa-2x mb-2" style="color: ${category.color};"></i>
            <h4 class="mb-1" style="color: ${category.color};">${count.toLocaleString()}</h4>
            <p class="mb-1 text-muted">${category.title}</p>
            <small class="text-muted">${percentage}% מהסך הכל</small>
          </div>
        </div>
      `;
    });
    html += '</div>';

    // Add total statistics
    html += `
      <div class="row mt-3">
        <div class="col-12">
          <div class="total-stats text-center p-3 bg-light border rounded">
            <h5 class="mb-1">סך הכל: ${stats.total.toLocaleString()} הודעות</h5>
            <small class="text-muted">עדכון אחרון: ${new Date().toLocaleString('he-IL')}</small>
          </div>
        </div>
      </div>
    `;

    container.innerHTML = html;
    console.log('✅ Category statistics loaded');
  } catch (error) {
    console.error('❌ Error loading category statistics:', error);
  }
}

/**
 * Load preferences overview
 */
async function loadPreferencesOverview() {
  try {
    const container = document.getElementById('preferencesOverview');
    if (!container) return;

    // Get notification preferences from the correct group
    // Get preferences from the system using built-in function
    let preferences = {};
    if (typeof window.getGroupPreferences === 'function') {
      try {
        const result = await window.getGroupPreferences('notification_settings');
        if (result && result.success && result.data && result.data.preferences) {
          preferences = result.data.preferences;
        } else {
          console.warn('Failed to get notification preferences from system');
        }
      } catch (error) {
        console.error('Error loading notification preferences:', error);
      }
    }

    // Get the most important notification preferences only - organized like preferences page
    const basicSettings = [
      { key: 'enableNotifications', title: 'הפעל התראות', type: 'boolean' },
      { key: 'notificationPopup', title: 'חלון קופץ התראות', type: 'boolean' },
      { key: 'notificationSound', title: 'צליל התראות', type: 'boolean' },
      { key: 'notificationDuration', title: 'משך זמן הצגת התראה (שניות)', type: 'integer' },
      { key: 'enableRealtimeNotifications', title: 'התראות בזמן אמת', type: 'boolean' },
      { key: 'enableSystemEventNotifications', title: 'התראות על אירועי מערכת', type: 'boolean' },
      { key: 'notifyOnTradeExecuted', title: 'התראה על ביצוע עסקה', type: 'boolean' },
      { key: 'notifyOnStopLoss', title: 'התראה על stop loss', type: 'boolean' }
    ];

    const notificationCategories = [
      { key: 'notifications_system_enabled', title: 'התראות מערכת', type: 'boolean' },
      { key: 'notifications_business_enabled', title: 'התראות עסקיות', type: 'boolean' },
      { key: 'notifications_ui_enabled', title: 'התראות ממשק משתמש', type: 'boolean' },
      { key: 'notifications_development_enabled', title: 'התראות פיתוח', type: 'boolean' },
      { key: 'notifications_performance_enabled', title: 'התראות ביצועים', type: 'boolean' }
    ];

    const consoleLogs = [
      { key: 'console_logs_system_enabled', title: 'לוגים מערכתיים', type: 'boolean' },
      { key: 'console_logs_business_enabled', title: 'לוגים עסקיים', type: 'boolean' },
      { key: 'console_logs_ui_enabled', title: 'לוגים ממשק משתמש', type: 'boolean' },
      { key: 'console_logs_development_enabled', title: 'לוגים פיתוח', type: 'boolean' },
      { key: 'console_logs_performance_enabled', title: 'לוגים ביצועים', type: 'boolean' }
    ];

    let html = '<div class="preferences-list">';
    
    // הגדרות בסיסיות
    html += '<div class="mb-4">';
    html += '<h6 class="text-primary mb-3">הגדרות בסיסיות:</h6>';
    basicSettings.forEach(item => {
      const value = preferences[item.key];
      const displayValue = item.type === 'boolean' ? 
        (value === true || value === 'true' ? '✅ פעיל' : '❌ כבוי') :
        (value || 'לא מוגדר');
      
      html += `
        <div class="preference-item d-flex justify-content-between align-items-center p-2 border-bottom">
          <span class="preference-title">${item.title}</span>
          <span class="preference-value ${item.type === 'boolean' ? (value === true || value === 'true' ? 'text-success' : 'text-danger') : 'text-info'}">${displayValue}</span>
        </div>
      `;
    });
    html += '</div>';

    // קטגוריות התראות
    html += '<div class="row">';
    html += '<div class="col-md-6">';
    html += '<h6 class="text-primary mb-3">התראות מערכת:</h6>';
    notificationCategories.forEach(item => {
      const value = preferences[item.key];
      const displayValue = item.type === 'boolean' ? 
        (value === true || value === 'true' ? '✅ פעיל' : '❌ כבוי') :
        (value || 'לא מוגדר');
      
      html += `
        <div class="preference-item d-flex justify-content-between align-items-center p-2 border-bottom">
          <span class="preference-title">${item.title}</span>
          <span class="preference-value ${item.type === 'boolean' ? (value === true || value === 'true' ? 'text-success' : 'text-danger') : 'text-info'}">${displayValue}</span>
        </div>
      `;
    });
    html += '</div>';

    // לוגים לקונסול
    html += '<div class="col-md-6">';
    html += '<h6 class="text-success mb-3">לוגים לקונסול:</h6>';
    consoleLogs.forEach(item => {
      const value = preferences[item.key];
      const displayValue = item.type === 'boolean' ? 
        (value === true || value === 'true' ? '✅ פעיל' : '❌ כבוי') :
        (value || 'לא מוגדר');
      
      html += `
        <div class="preference-item d-flex justify-content-between align-items-center p-2 border-bottom">
          <span class="preference-title">${item.title}</span>
          <span class="preference-value ${item.type === 'boolean' ? (value === true || value === 'true' ? 'text-success' : 'text-danger') : 'text-info'}">${displayValue}</span>
        </div>
      `;
    });
    html += '</div>';
    html += '</div>';
    html += '</div>';

    container.innerHTML = html;
    console.log('✅ Preferences overview loaded with correct data');
  } catch (error) {
    console.error('❌ Error loading preferences overview:', error);
  }
}

/**
 * Load all overview data
 */
async function loadOverviewData() {
  await Promise.all([
    loadCategoriesOverview(),
    loadPreferencesOverview(),
    loadCategoryStats()
  ]);
}

// Export functions to global scope
window.loadCategoriesOverview = loadCategoriesOverview;
window.loadPreferencesOverview = loadPreferencesOverview;
window.loadCategoryStats = loadCategoryStats;
window.loadOverviewData = loadOverviewData;

class NotificationsCenter {
  constructor() {
    this.history = [];
    this.notifications = []; // הוספתי את זה
    this.preferences = {}; // העדפות התראות מהמערכת הגלובלית
    this.stats = {
      success: 0,
      error: 0,
      warning: 0,
      info: 0,
      // קטגוריות חדשות
      system: 0,
      business: 0,
      ui: 0,
      development: 0,
      performance: 0,
    };

    this.init().catch(error => {
      console.error('❌ שגיאה באתחול מרכז התראות:', error);
    });
  }

  async init() {
    console.log('🚀 אתחול מרכז התראות... (1.1.0 - Connected to Global Preferences System)');

    // טעינת העדפות התראות מהמערכת הגלובלית
    await this.loadNotificationPreferences();

    // אתחול UI
    await this.initUI();

    // אתחול סטטיסטיקות
    this.updateStats();

    // חיבור לאירועי WebSocket
    this.setupWebSocketEvents();

    // טעינת היסטוריה
    this.loadHistory().then(async () => {
      console.log('✅ היסטוריה נטענה בהצלחה');
      // עדכון סטטיסטיקות אחרי טעינת ההיסטוריה
      this.updateStats();
      await this.updateStatsUI();
      
      // טעינת נתוני סקירה כללית
      if (typeof window.loadOverviewData === 'function') {
        window.loadOverviewData();
      }
    }).catch(error => {
      console.warn('⚠️ שגיאה בטעינת היסטוריה:', error);
    });

    // הוספת התראות בדיקה
    this.addTestNotifications();

    // רענון אוטומטי
    this.startAutoRefresh();

    console.log('✅ מרכז התראות אותחל בהצלחה (1.0.9 - Fixed + Debug + Settings + Filter + Stats + Layout - Live Removed + Settings Fix + AutoRefresh Fix)');
  }

  async initUI() {
    // עדכון סטטוס חיבור - מציג כפעיל אם אין realtime client
    if (window.realtimeNotificationsClient) {
      this.updateConnectionStatus('connecting');
    } else {
      this.updateConnectionStatus('connected');
    }

    // הגדרות התראות הועברו למערכת ההעדפות הגלובלית

    // עדכון סטטיסטיקות
    this.updateStatsUI();
    
    // בדיקת חיבור WebSocket אחרי טעינה
    setTimeout(() => {
      try {
        if (this && typeof this.checkWebSocketConnection === 'function') {
          this.checkWebSocketConnection();
        }
      } catch (error) {
        console.warn('⚠️ Error in WebSocket connection check:', error);
      }
    }, 1000);
  }

  setupWebSocketEvents() {
    if (window.realtimeNotificationsClient) {
      // אירועי חיבור
      window.realtimeNotificationsClient.on('connect', () => {
        this.updateConnectionStatus('connected');
        this.addNotification('info', 'מרכז התראות', 'חובר לשרת בהצלחה', 'now');
      });

      window.realtimeNotificationsClient.on('disconnect', () => {
        this.updateConnectionStatus('disconnected');
        this.addNotification('warning', 'מרכז התראות', 'נותק מהשרת', 'now');
      });

      // אירועי התראות - עובדים עם מערכת ההעדפות הגלובלית
      window.realtimeNotificationsClient.on('background_task_started', data => {
        if (this.preferences.enableBackgroundTaskNotifications === 'true' || this.preferences.enableBackgroundTaskNotifications === true) {
          this.addNotification('info', 'משימה ברקע', `התחילה: ${data.task_name}`, 'now');
        }
      });

      window.realtimeNotificationsClient.on('background_task_completed', data => {
        if (this.preferences.enableBackgroundTaskNotifications === 'true' || this.preferences.enableBackgroundTaskNotifications === true) {
          this.addNotification('success', 'משימה הושלמה', `${data.task_name} הושלמה בהצלחה`, 'now');
        }
      });

      window.realtimeNotificationsClient.on('background_task_failed', data => {
        if (this.preferences.enableBackgroundTaskNotifications === 'true' || this.preferences.enableBackgroundTaskNotifications === true) {
          this.addNotification('error', 'שגיאה במשימה', `${data.task_name} נכשלה: ${data.error}`, 'now');
        }
      });

      window.realtimeNotificationsClient.on('data_updated', data => {
        if (this.preferences.enableDataUpdateNotifications === 'true' || this.preferences.enableDataUpdateNotifications === true) {
          this.addNotification('info', 'נתונים עודכנו', `${data.table} עודכן בהצלחה`, 'now');
        }
      });

      window.realtimeNotificationsClient.on('data_error', data => {
        if (this.preferences.enableDataUpdateNotifications === 'true' || this.preferences.enableDataUpdateNotifications === true) {
          this.addNotification('error', 'שגיאת נתונים', `שגיאה ב-${data.table}: ${data.error}`, 'now');
        }
      });

      window.realtimeNotificationsClient.on('external_data_update', data => {
        if (this.preferences.enableExternalDataNotifications === 'true' || this.preferences.enableExternalDataNotifications === true) {
          this.addNotification('success', 'נתונים חיצוניים', `${data.provider} עודכן: ${data.ticker_count} טיקרים`, 'now');
        }
      });

      window.realtimeNotificationsClient.on('external_data_error', data => {
        if (this.preferences.enableExternalDataNotifications === 'true' || this.preferences.enableExternalDataNotifications === true) {
          this.addNotification('error', 'שגיאת נתונים חיצוניים', `${data.provider}: ${data.error}`, 'now');
        }
      });

      window.realtimeNotificationsClient.on('system_event', data => {
        if (this.preferences.enableSystemEventNotifications === 'true' || this.preferences.enableSystemEventNotifications === true) {
          this.addNotification('info', 'אירוע מערכת', data.message, 'now');
        }
      });
    }
  }

  addNotification(type, title, message, time = 'now') {
    // Auto-detect category if not provided
    let category = 'general';
    if (typeof window.detectNotificationCategory === 'function') {
      try {
        category = window.detectNotificationCategory(message, type, title, {
          fileName: window.location.pathname,
          functionName: 'addNotification',
          stackTrace: ''
        });
      } catch (error) {
        console.warn('Failed to detect category in addNotification, using default:', error);
        // Fallback to type-based category
        switch (type) {
          case 'success': category = 'business'; break;
          case 'error': category = 'system'; break;
          case 'warning': category = 'system'; break;
          case 'info': category = 'ui'; break;
          default: category = 'general';
        }
      }
    } else {
      // Fallback to type-based category
      switch (type) {
        case 'success': category = 'business'; break;
        case 'error': category = 'system'; break;
        case 'warning': category = 'system'; break;
        case 'info': category = 'ui'; break;
        default: category = 'general';
      }
    }

    const notification = {
      id: Date.now() + Math.random(),
      type,
      title,
      message,
      category,
      time: time === 'now' ? new Date() : new Date(time),
      timestamp: Date.now(),
    };

    // הוספה להיסטוריה (כל ההתראות)
    this.history.unshift(notification);
    if (this.history.length > 1000) {
      this.history = this.history.slice(0, 1000);
    }

    // עדכון סטטיסטיקות
    this.stats[type]++;
    this.updateStats();

    // עדכון UI
    this.updateHistoryUI();
    this.updateStatsUI();
    this.updateOverviewStats();

    // שמירה ללוקל סטורג' - הוסרה כי המערכת עברה ל-IndexedDB
    // this.saveToLocalStorage(); - הוסרה

    // שמירה לקובץ לוג מבוטלת זמנית למניעת עומס
    // this.saveToLogFile(notification);

    // הצגת הודעה לפי העדפות
    if (this.preferences.notificationPopup === 'true' || this.preferences.notificationPopup === true) {
      this.showNotificationPopup(notification);
    }

    // צלילים לפי העדפות
    if (this.preferences.notificationSound === 'true' || this.preferences.notificationSound === true) {
      // this.playNotificationSound(type);
    }
  }

  showNotificationPopup(notification) {
    // הצגת התראה ישירה ללא לולאה
    const popup = document.createElement('div');
    popup.className = `notification-popup ${notification.type}`;
    popup.innerHTML = `
      <div class="popup-header">
        <span class="popup-title">${notification.title}</span>
        <button class="popup-close" onclick="this.parentElement.parentElement.remove()">×</button>
      </div>
      <div class="popup-message">${notification.message}</div>
    `;

    document.body.appendChild(popup);

    // הסרה אוטומטית לפי העדפות
    const duration = parseInt(this.preferences.notificationDuration || 5) * 1000;
    setTimeout(() => {
      if (popup.parentElement) {
        popup.remove();
      }
    }, duration);
  }

  static playNotificationSound(type) {
    // יצירת צליל התראה פשוט
    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);

    // הגדרת תדירות לפי סוג התראה
    let frequency = 800;
    switch (type) {
    case 'success':
      frequency = 1000;
      break;
    case 'error':
      frequency = 400;
      break;
    case 'warning':
      frequency = 600;
      break;
    case 'info':
      frequency = 800;
      break;
    }

    oscillator.frequency.setValueAtTime(frequency, audioContext.currentTime);
    gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);

    oscillator.start();
    oscillator.stop(audioContext.currentTime + 0.1);
  }

  updateConnectionStatus(status = 'connecting') {
    // בדיקה אם האלמנטים קיימים (רק בעמוד מרכז ההתראות)
    const overallStatusElement = document.getElementById('overallStatus');
    const websocketStatus = document.getElementById('websocketStatus');
    const connectionTimeElement = document.getElementById('connectionTime');
    const messagesSentElement = document.getElementById('messagesSent');

    // בדיקה שכל האלמנטים קיימים
    if (!overallStatusElement || !websocketStatus || !connectionTimeElement || !messagesSentElement) {
      return;
    }

    switch (status) {
    case 'connected':
      websocketStatus.textContent = 'מחובר';
      websocketStatus.className = 'text-success';
      overallStatusElement.textContent = 'מחובר';
      overallStatusElement.className = 'text-success';
      break;
    case 'disconnected':
      websocketStatus.textContent = 'מנותק';
      websocketStatus.className = 'text-danger';
      connectionTimeElement.textContent = '-';
      messagesSentElement.textContent = '0';
      overallStatusElement.textContent = 'מנותק';
      overallStatusElement.className = 'text-danger';
      break;
    case 'connecting':
      websocketStatus.textContent = 'מתחבר...';
      websocketStatus.className = 'text-warning';
      connectionTimeElement.textContent = '-';
      messagesSentElement.textContent = '0';
      overallStatusElement.textContent = 'מתחבר...';
      overallStatusElement.className = 'text-warning';
      break;
    }

    // עדכון זמן חיבור והודעות
    if (status === 'connected' && window.realtimeNotificationsClient) {
      try {
        const stats = window.realtimeNotificationsClient.getConnectionStats();

        if (stats && stats.connectedAt) {
          const connectionTime = new Date(stats.connectedAt);
          const now = new Date();
          const diff = Math.floor((now - connectionTime) / 1000);
          connectionTimeElement.textContent = NotificationsCenter.formatDuration(diff);
        } else {
          connectionTimeElement.textContent = 'עכשיו';
        }

        messagesSentElement.textContent = stats && stats.totalMessages ? stats.totalMessages : 0;
      } catch {
        // שגיאה בעדכון סטטיסטיקות חיבור
        connectionTimeElement.textContent = 'עכשיו';
        messagesSentElement.textContent = '0';
      }
    }
  }


  updateHistoryUI() {
    console.log('🔍 updateHistoryUI called, history length:', this.history.length);
    const container = document.getElementById('unified-logs-container');
    if (!container) {
      console.log('❌ unified-logs-container not found');
      return; // לא בעמוד מרכז ההתראות
    }

    if (this.history.length === 0) {
      console.log('❌ History is empty, showing no history message');
      container.innerHTML = `
                <div class="no-history">
                    <i class="fas fa-history"></i>
                    <p>אין היסטוריית התראות</p>
                </div>
            `;
      return;
    }

    console.log('✅ History has', this.history.length, 'notifications, updating UI');

    // פילטור לפי בחירת המשתמש
    console.log('🔍 Getting filter elements...');
    const filterElement = document.getElementById('historyFilter');
    const periodElement = document.getElementById('historyPeriod');

    if (!filterElement || !periodElement) {
      console.log('❌ Filter elements not found');
      return; // אלמנטי פילטר לא קיימים
    }

    console.log('✅ Filter elements found');
    const filter = filterElement.value;
    const period = periodElement.value;

    let filteredHistory = this.history;
    console.log('🔍 Original history length:', this.history.length);

    // פילטר לפי סוג
    if (filter) {
      filteredHistory = filteredHistory.filter(n => n.type === filter);
      console.log('🔍 After type filter:', filteredHistory.length);
    }

    // פילטר לפי זמן
    console.log('🔍 Applying time filter...');
    const now = Date.now();
    const periodMs = NotificationsCenter.getPeriodInMs(period);
    console.log('🔍 Period MS:', periodMs);
    filteredHistory = filteredHistory.filter(n => now - n.timestamp <= periodMs);
    console.log('🔍 After time filter:', filteredHistory.length);

    if (filteredHistory.length === 0) {
      container.innerHTML = `
                <div class="no-history">
                    <i class="fas fa-filter"></i>
                    <p>אין התראות לפי הפילטרים שנבחרו</p>
                </div>
            `;
      return;
    }

    container.innerHTML = filteredHistory.map(notification => this.createNotificationHTML(notification)).join('');
  }

  updateStats() {
    // עדכון סטטיסטיקות פנימיות (מבוסס על היסטוריה)
    this.stats.success = this.history.filter(n => n.type === 'success').length;
    this.stats.error = this.history.filter(n => n.type === 'error').length;
    this.stats.warning = this.history.filter(n => n.type === 'warning').length;
    this.stats.info = this.history.filter(n => n.type === 'info').length;
    this.stats.total = this.stats.success + this.stats.error + this.stats.warning + this.stats.info;
    
    // עדכון סטטיסטיקות קטגוריות
    this.stats.system = this.history.filter(n => n.category === 'system').length;
    this.stats.business = this.history.filter(n => n.category === 'business').length;
    this.stats.ui = this.history.filter(n => n.category === 'ui').length;
    this.stats.development = this.history.filter(n => n.category === 'development').length;
    this.stats.performance = this.history.filter(n => n.category === 'performance').length;
    this.stats.security = this.history.filter(n => n.category === 'security').length;
    this.stats.network = this.history.filter(n => n.category === 'network').length;
    this.stats.database = this.history.filter(n => n.category === 'database').length;
    this.stats.user = this.history.filter(n => n.category === 'user').length;
    this.stats.trade = this.history.filter(n => n.category === 'trade').length;
    this.stats.ticker = this.history.filter(n => n.category === 'ticker').length;
    this.stats.alert = this.history.filter(n => n.category === 'alert').length;
    this.stats.general = this.history.filter(n => n.category === 'general').length;
  }

  async updateStatsUI() {
    // עדכון סטטיסטיקות מפורטות
    const successCount = document.getElementById('successCount');
    const errorCount = document.getElementById('errorCount');
    const warningCount = document.getElementById('warningCount');
    const infoCount = document.getElementById('infoCount');
    const totalCount = document.getElementById('totalCount');

    if (successCount) {successCount.textContent = this.stats.success;}
    if (errorCount) {errorCount.textContent = this.stats.error;}
    if (warningCount) {warningCount.textContent = this.stats.warning;}
    if (infoCount) {infoCount.textContent = this.stats.info;}
    if (totalCount) {totalCount.textContent = this.stats.success + this.stats.error + this.stats.warning + this.stats.info;}

    // עדכון סטטיסטיקות סקירה כללית
    await this.updateOverviewStats();
    
    // עדכון קטגוריות הודעות
    if (typeof window.loadCategoriesOverview === 'function') {
      window.loadCategoriesOverview();
    }
    if (typeof window.loadCategoryStats === 'function') {
      window.loadCategoryStats();
    }
  }

  async updateOverviewStats() {
    // עדכון סטטיסטיקות בסקירה הכללית
    const activeAlertsCount = document.getElementById('activeAlertsCount');
    const newMessagesCount = document.getElementById('newMessagesCount');
    const lastUpdateTime = document.getElementById('lastUpdateTime');
    const systemStatus = document.getElementById('systemStatus');

    // טעינת נתונים מהלוג המאוחד לקבלת מספר מדויק
    let totalNotifications = this.history.length;
    let allNotifications = [...this.history];
    
    try {
      if (window.UnifiedLogAPI) {
        const logData = await window.UnifiedLogAPI.getLogData('notificationHistory');
        if (logData && Array.isArray(logData)) {
          allNotifications = logData;
          totalNotifications = logData.length;
          console.log('📊 עדכון סטטיסטיקות מהלוג המאוחד:', totalNotifications, 'התראות');
        }
      }
    } catch (error) {
      console.warn('שגיאה בטעינת נתונים מהלוג המאוחד לסטטיסטיקות:', error);
    }

    if (activeAlertsCount) {
      activeAlertsCount.textContent = totalNotifications;
    }
    
    if (newMessagesCount) {
      // ספירת הודעות חדשות מהשעה האחרונה
      const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000);
      const newMessages = allNotifications.filter(n => {
        const notificationTime = new Date(n.time || n.timestamp || n.createdAt);
        return notificationTime > oneHourAgo;
      }).length;
      newMessagesCount.textContent = newMessages;
    }
    
    if (lastUpdateTime) {
      if (allNotifications.length > 0) {
        const lastNotification = allNotifications[0];
        const lastTime = lastNotification.time || lastNotification.timestamp || lastNotification.createdAt;
        lastUpdateTime.textContent = NotificationsCenter.getTimeAgo(lastTime);
      } else {
        lastUpdateTime.textContent = '-';
      }
    }
    
    if (systemStatus) {
      systemStatus.textContent = 'פעיל';
      systemStatus.className = 'text-success';
    }
  }

  async loadNotificationPreferences() {
    try {
      console.log('🔧 טעינת העדפות התראות מהמערכת הגלובלית...');
      
      // טעינת העדפות התראות מהמערכת הגלובלית
      if (typeof window.getGroupPreferences === 'function') {
        const prefs = await window.getGroupPreferences('notification_settings');
        this.preferences = prefs;
        console.log('✅ העדפות התראות נטענו:', this.preferences);
      } else {
        console.warn('⚠️ מערכת ההעדפות הגלובלית לא זמינה, שימוש בברירות מחדל');
        this.preferences = {
          enableNotifications: true,
          enableRealtimeNotifications: true,
          enableBackgroundTaskNotifications: true,
          enableDataUpdateNotifications: true,
          enableExternalDataNotifications: true,
          enableSystemEventNotifications: true,
          notificationPopup: true,
          notificationSound: true,
          notificationDuration: 5,
          notificationMaxHistory: 1000
        };
      }
    } catch (error) {
      console.error('❌ שגיאה בטעינת העדפות התראות:', error);
      // ברירות מחדל במקרה של שגיאה
      this.preferences = {
        enableNotifications: true,
        enableRealtimeNotifications: true,
        enableBackgroundTaskNotifications: true,
        enableDataUpdateNotifications: true,
        enableExternalDataNotifications: true,
        enableSystemEventNotifications: true,
        notificationPopup: true,
        notificationSound: true,
        notificationDuration: 5,
        notificationMaxHistory: 1000
      };
    }
  }

  createNotificationHTML(notification) {
    const timeAgo = NotificationsCenter.getTimeAgo(notification.time);
    const iconClass = NotificationsCenter.getIconClass(notification.type);

    return `
            <div class="notification-item ${notification.type}">
                <div class="notification-icon">
                    <i class="${iconClass}"></i>
                </div>
                <div class="notification-content">
                    <div class="notification-line">
                        <span class="notification-title">${notification.title}</span>
                        <span class="notification-separator"> --> </span>
                        <span class="notification-message">${notification.message}</span>
                        <span class="notification-separator"> --> </span>
                        <span class="notification-time">${timeAgo}</span>
                    </div>
                    ${notification.page ? `<div class="notification-page">📄 עמוד: ${notification.page}</div>` : ''}
                </div>
            </div>
        `;
  }

  static getIconClass(type) {
    switch (type) {
    case 'success':
      return 'fas fa-check-circle';
    case 'error':
      return 'fas fa-exclamation-circle';
    case 'warning':
      return 'fas fa-exclamation-triangle';
    case 'info':
      return 'fas fa-info-circle';
    default:
      return 'fas fa-bell';
    }
  }

  getTypeIcon(type) {
    switch (type) {
      case 'success':
        return '✅';
      case 'error':
        return '❌';
      case 'warning':
        return '⚠️';
      case 'info':
        return 'ℹ️';
      default:
        return '🔔';
    }
  }

  static getTimeAgo(_date) {
    // בדיקה שהפרמטר הוא אובייקט Date תקין
    let date = _date;
    if (!date || !(date instanceof Date)) {
      try {
        date = new Date(date);
      } catch (error) {
        // console.warn('שגיאה בהמרת תאריך:', error);
        return 'לא ידוע';
      }
    }

    const now = new Date();
    const diff = Math.floor((now - date) / 1000);

    if (diff < 60) {return 'עכשיו';}
    if (diff < 3600) {return `לפני ${Math.floor(diff / 60)} דקות`;}
    if (diff < 86400) {return `לפני ${Math.floor(diff / 3600)} שעות`;}
    if (diff < 2592000) {return `לפני ${Math.floor(diff / 86400)} ימים`;}

    return date.toLocaleDateString('he-IL');
  }

  static getPeriodInMs(period) {
    switch (period) {
    case '1h': return 3600000;
    case '24h': return 86400000;
    case '7d': return 604800000;
    case '30d': return 2592000000;
    default: return 86400000;
    }
  }

  static formatDuration(seconds) {
    if (seconds < 60) {return `${seconds} שניות`;}
    if (seconds < 3600) {return `${Math.floor(seconds / 60)} דקות`;}
    if (seconds < 86400) {return `${Math.floor(seconds / 3600)} שעות`;}
    return `${Math.floor(seconds / 86400)} ימים`;
  }

  // הגדרות התראות הועברו למערכת ההעדפות הגלובלית

  // שמירה ללוקל סטורג'
  // שמירה ללוקל סטורג' - הוסרה כי המערכת עברה ל-IndexedDB
  // saveToLocalStorage() - הוסרה

  // טעינה מלוקל סטורג' - הוסרה כי המערכת עברה ל-IndexedDB  
  // loadFromLocalStorage() - הוסרה

  async loadHistory() {
    // טעינת היסטוריית התראות - עבר ל-IndexedDB
    // this.loadFromLocalStorage(); - הוסרה

    // טעינת היסטוריה גלובלית מכל העמודים
    await this.loadGlobalHistory();

    // טעינת רשימת עמודים לסינון
    this.loadPageFilterOptions();

    // עדכון סטטיסטיקות לאחר טעינה
    this.updateStats();

    // עדכון UI
    this.updateHistoryUI();
    this.updateStatsUI();
    this.updateOverviewStats();
  }

  loadPageFilterOptions() {
    try {
      const pageFilterSelect = document.getElementById('pageFilter');
      if (!pageFilterSelect) return;

      // קבלת רשימת עמודים ייחודיים מההיסטוריה
      const uniquePages = [...new Set(this.history.map(n => n.page).filter(page => page))];
      
      // ניקוי אפשרויות קיימות (למעט "כל העמודים")
      pageFilterSelect.innerHTML = '<option value="">כל העמודים</option>';
      
      // הוספת עמודים ייחודיים
      uniquePages.sort().forEach(page => {
        const option = document.createElement('option');
        option.value = page;
        option.textContent = page;
        pageFilterSelect.appendChild(option);
      });

      console.log('📄 רשימת עמודים לסינון נטענה:', uniquePages.length, 'עמודים');
    } catch (error) {
      console.warn('שגיאה בטעינת רשימת עמודים:', error);
    }
  }

  /**
   * Convert new format to old format for compatibility
   */
  convertNewFormatToOldFormat(newFormatHistory) {
    return newFormatHistory.map(item => ({
      id: item.id,
      type: item.type || item.level || 'info',
      title: item.title || 'ללא כותרת',
      message: item.message || item.error || 'ללא הודעה',
      time: new Date(item.timestamp || item.time || Date.now()),
      timestamp: item.timestamp || item.time || Date.now(),
      page: item.page || window.location.pathname,
      url: item.url || window.location.href,
      category: item.category || 'general'
    }));
  }

  /**
   * Merge histories and remove duplicates
   */
  mergeHistories(oldHistory, newHistory) {
    const merged = [...oldHistory];
    const existingIds = new Set(oldHistory.map(item => item.id));
    
    newHistory.forEach(item => {
      if (!existingIds.has(item.id)) {
        merged.push(item);
      }
    });
    
    // Sort by timestamp
    return merged.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
  }

  async loadGlobalHistory() {
    try {
      console.log('🔧 טוען היסטוריה גלובלית...');
      
      // טעינה מהלוג המאוחד (המקור העיקרי)
      let globalHistory = [];
      try {
        if (window.UnifiedLogAPI) {
          const logData = await window.UnifiedLogAPI.getLogData('notificationHistory');
          if (logData && Array.isArray(logData)) {
            globalHistory = logData;
            console.log('📚 היסטוריה נטענה מהלוג המאוחד:', globalHistory.length, 'התראות');
          }
        }
      } catch (e) {
        console.warn('שגיאה בטעינה מהלוג המאוחד:', e);
      }

      // Fallback ל-localStorage אם הלוג המאוחד לא זמין
      if (globalHistory.length === 0) {
        try {
          let savedHistory = null;
          if (window.UnifiedCacheManager && window.UnifiedCacheManager.isInitialized()) {
            savedHistory = await window.UnifiedCacheManager.get('tiktrack_global_notifications_history');
          } else {
            savedHistory = localStorage.getItem('tiktrack_global_notifications_history'); // fallback
          }
          
          if (savedHistory) {
            globalHistory = typeof savedHistory === 'string' ? JSON.parse(savedHistory) : savedHistory;
            console.log('📚 היסטוריה נטענה מ-localStorage (fallback):', globalHistory.length, 'התראות');
          }
        } catch (e) {
          console.warn('שגיאה בטעינה מ-localStorage:', e);
        }
      }

      // טעינה מ-IndexedDB אם זמין
      if (window.UnifiedCacheManager && window.UnifiedCacheManager.initialized) {
        try {
          const indexedDBHistory = await window.UnifiedCacheManager.get('notification_history');
          if (indexedDBHistory && Array.isArray(indexedDBHistory)) {
            // מיזוג עם היסטוריה קיימת
            const mergedHistory = this.mergeHistories(globalHistory, indexedDBHistory);
            globalHistory = mergedHistory;
            console.log('📚 היסטוריה מוזגה עם IndexedDB:', globalHistory.length, 'התראות');
          }
        } catch (error) {
          console.warn('שגיאה בטעינה מ-IndexedDB:', error);
        }
      }

      // עדכון היסטוריה מקומית
      this.history = globalHistory;
      console.log('✅ היסטוריה סופית:', this.history.length, 'התראות');

      // טעינת סטטיסטיקות גלובליות
      if (typeof window.loadGlobalNotificationStats === 'function') {
        try {
          const globalStats = await window.loadGlobalNotificationStats();
          console.log('📊 סטטיסטיקות גלובליות נטענו:', globalStats);

          // עדכון סטטיסטיקות מקומיות
          this.stats = {
            success: Math.max(this.stats.success, globalStats.success || 0),
            error: Math.max(this.stats.error, globalStats.error || 0),
            warning: Math.max(this.stats.warning, globalStats.warning || 0),
            info: Math.max(this.stats.info, globalStats.info || 0),
          };
        } catch (error) {
          console.warn('שגיאה בטעינת סטטיסטיקות:', error);
        }
      }
    } catch (error) {
      console.warn('שגיאה בטעינת היסטוריה גלובלית:', error);
    }
  }

  mergeHistories(localHistory, globalHistory) {
    // יצירת מפה למניעת כפילויות
    const historyMap = new Map();

    // הוספת היסטוריה גלובלית
    globalHistory.forEach(notification => {
      const key = `${notification.type}-${notification.title}-${notification.message}-${notification.timestamp}`;
      historyMap.set(key, notification);
    });

    // הוספת היסטוריה מקומית (לא תדרוס גלובלית)
    localHistory.forEach(notification => {
      const key = `${notification.type}-${notification.title}-${notification.message}-${notification.timestamp}`;
      if (!historyMap.has(key)) {
        historyMap.set(key, notification);
      }
    });

    // המרה חזרה למערך ומיון לפי זמן
    return Array.from(historyMap.values()).sort((a, b) => b.timestamp - a.timestamp);
  }

  addTestNotifications() {
    // הוספת התראות בדיקה אם אין התראות קיימות
    // Disabled test notifications to reduce noise
    if (false && this.history.length === 0) {
      console.log('📝 הוספת התראות בדיקה...');
      
      this.addNotification('success', 'מערכת', 'מרכז ההתראות אותחל בהצלחה', 'now');
      this.addNotification('info', 'חיבור', 'מתחבר לשרת WebSocket...', 'now');
      this.addNotification('warning', 'בדיקה', 'זוהי התראת בדיקה למערכת', 'now');
      
      console.log('✅ התראות בדיקה נוספו');
    }
    
    // הגדרות התראות הועברו למערכת ההעדפות הגלובלית
  }

  checkWebSocketConnection() {
    // בדיקת חיבור WebSocket
    if (window.realtimeNotificationsClient) {
      const isConnected = window.realtimeNotificationsClient.isConnected();
      console.log('🔍 בדיקת חיבור WebSocket:', isConnected ? 'מחובר' : 'לא מחובר');
      
      if (isConnected) {
        this.updateConnectionStatus('connected');
      } else {
        this.updateConnectionStatus('disconnected');
      }
    } else {
      // realtimeNotificationsClient not available - show as active since notifications work
      console.log('🔍 realtimeNotificationsClient לא זמין - מציג כפעיל');
      this.updateConnectionStatus('connected');
    }
  }

  // שמירה לקובץ לוג
  static saveToLogFile(notification) {
    try {
      const logEntry = {
        timestamp: new Date().toISOString(),
        type: notification.type,
        title: notification.title,
        message: notification.message,
        userAgent: navigator.userAgent,
        url: window.location.href,
      };

      // שליחה לשרת לשמירה בקובץ לוג
      fetch('/api/logs/notification', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(logEntry),
      }).catch(error => {
        // console.warn('לא ניתן לשמור בקובץ לוג:', error);
      });
    } catch (error) {
      // console.warn('שגיאה בשמירה לקובץ לוג:', error);
    }
  }

  // פונקציות ציבוריות

  async clearHistory() {
    // Function to execute history clearing
    const executeClearHistory = () => {
      this.history = [];
      this.stats = { success: 0, error: 0, warning: 0, info: 0 };

      this.updateHistoryUI();
      this.updateStatsUI();
      this.updateOverviewStats();
      // this.saveToLocalStorage(); - הוסרה כי המערכת עברה ל-IndexedDB

      // הודעה ישירה לממשק ללא לולאה
      console.log('✅ היסטוריית ההתראות נוקתה בהצלחה');
    };
    
    // Use notification system or fallback to confirm
    if (typeof window.showConfirmationDialog === 'function') {
      window.showConfirmationDialog(
        'ניקוי היסטוריה',
        'האם אתה בטוח שברצונך לנקות את כל היסטוריית ההתראות?',
        executeClearHistory,
        () => console.log('❌ ניקוי היסטוריה - משתמש ביטל')
      );
    } else {
      let confirmed = false;
      if (typeof showConfirmationDialog === 'function') {
        confirmed = await new Promise(resolve => {
          showConfirmationDialog(
            'האם אתה בטוח שברצונך לנקות את כל היסטוריית ההתראות?',
            () => resolve(true),
            () => resolve(false),
            'ניקוי היסטוריה',
            'נקה',
            'ביטול'
          );
        });
      } else {
        confirmed = window.confirm('האם אתה בטוח שברצונך לנקות את כל היסטוריית ההתראות?');
      }
      
      if (confirmed) {
        executeClearHistory();
      } else {
        console.log('❌ ניקוי היסטוריה - משתמש ביטל');
      }
    }
  }

  async refreshNotifications() {
    try {
      console.log('🔄 מרענן נתוני התראות...');
      
      // טעינה מחדש של היסטוריה
      await this.loadHistory();
      
      // עדכון UI
      this.updateHistoryUI();
      this.updateStatsUI();
      this.updateOverviewStats();
      
      // עדכון סקירות
      if (typeof window.loadCategoriesOverview === 'function') {
        await window.loadCategoriesOverview();
      }
      if (typeof window.loadCategoryStats === 'function') {
        await window.loadCategoryStats();
      }
      if (typeof window.loadPreferencesOverview === 'function') {
        await window.loadPreferencesOverview();
      }
      
      console.log('✅ ההתראות רועננו בהצלחה');
    } catch (error) {
      console.error('❌ שגיאה ברענון התראות:', error);
    }
  }

  // generateDetailedLog function moved to global scope below

  filterHistory() {
    const typeFilter = document.getElementById('historyFilter')?.value || '';
    const pageFilter = document.getElementById('pageFilter')?.value || '';
    const period = document.getElementById('historyPeriod')?.value || '24h';
    
    // סינון לפי זמן
    const now = new Date();
    let filteredHistory = this.history;
    
    if (period !== 'all') {
      const periodMs = this.getPeriodMs(period);
      const cutoffTime = new Date(now.getTime() - periodMs);
      filteredHistory = filteredHistory.filter(notification => 
        notification.time && new Date(notification.time) >= cutoffTime
      );
    }
    
    // סינון לפי סוג
    if (typeFilter) {
      filteredHistory = filteredHistory.filter(notification => notification.type === typeFilter);
    }
    
    // סינון לפי עמוד
    if (pageFilter) {
      filteredHistory = filteredHistory.filter(notification => notification.page === pageFilter);
    }
    
    // עדכון UI עם ההיסטוריה המסוננת
    this.updateHistoryUIWithFilteredData(filteredHistory);
  }

  updateHistoryUIWithFilteredData(filteredHistory) {
    const historyContainer = document.getElementById('notificationHistory');
    if (!historyContainer) return;

    // ניקוי קונטיינר
    historyContainer.innerHTML = '';

    // בדיקה אם יש היסטוריה מסוננת
    if (!filteredHistory || filteredHistory.length === 0) {
      historyContainer.innerHTML = `
        <div class="empty-state">
          <i class="fas fa-filter"></i>
          <p>אין התראות המתאימות לסינון הפעיל</p>
        </div>
      `;
      return;
    }

    // הוספת התראות מסוננות לרשימה
    filteredHistory.forEach(notification => {
      const notificationHTML = this.createNotificationHTML(notification);
      const notificationElement = document.createElement('div');
      notificationElement.innerHTML = notificationHTML;
      historyContainer.appendChild(notificationElement.firstElementChild);
    });
  }

  startAutoRefresh() {
    // רענון אוטומטי כל 30 שניות
    setInterval(() => {
      // עדכון סטטוס חיבור רק אם יש שינוי
      if (window.realtimeNotificationsClient) {
        const isConnected = window.realtimeNotificationsClient.isConnected();
        const currentStatus = NotificationsCenter.getCurrentConnectionStatus();

        if (isConnected && currentStatus !== 'connected') {
          this.updateConnectionStatus('connected');
        } else if (!isConnected && currentStatus !== 'disconnected') {
          this.updateConnectionStatus('disconnected');
        }
      } else {
        // realtimeNotificationsClient not available - keep showing as connected
        const currentStatus = NotificationsCenter.getCurrentConnectionStatus();
        if (currentStatus !== 'connected') {
          this.updateConnectionStatus('connected');
        }
      }

    }, 30000);

    // עדכון זמן חיבור כל שנייה כאשר מחובר
    setInterval(() => {
      if (window.realtimeNotificationsClient && window.realtimeNotificationsClient.isConnected()) {
        this.updateConnectionTime();
      }
    }, 1000);

    // עדכון סטטיסטיקות כל 30 שניות
    setInterval(() => {
      this.updateOverviewStats();
    }, 30000);
  }

  updateConnectionTime() {
    try {
      const connectionTimeElement = document.getElementById('connectionTime');
      if (!connectionTimeElement) {
        return; // לא בעמוד מרכז ההתראות
      }

      if (window.realtimeNotificationsClient) {
        const stats = window.realtimeNotificationsClient.getConnectionStats();
        if (stats && stats.connectedAt) {
          const connectionTime = new Date(stats.connectedAt);
          const now = new Date();
          const diff = Math.floor((now - connectionTime) / 1000);
          connectionTimeElement.textContent = NotificationsCenter.formatDuration(diff);
        }
      }
    } catch (error) {
      // console.warn('שגיאה בעדכון זמן חיבור:', error);
    }
  }

  static getCurrentConnectionStatus() {
    try {
      const statusDot = document.getElementById('connectionStatus');
      if (!statusDot) {
        return 'connecting'; // לא בעמוד מרכז ההתראות
      }

      if (statusDot.querySelector('.connected')) {return 'connected';}
      if (statusDot.querySelector('.disconnected')) {return 'disconnected';}
      if (statusDot.querySelector('.connecting')) {return 'connecting';}
    } catch (error) {
      // console.warn('שגיאה בקבלת סטטוס חיבור נוכחי:', error);
    }
    return 'connecting';
  }
}

// פונקציה להעתקת היסטוריה מסוננת ללוח
async function copyFilteredHistoryToClipboard() {
  try {
    console.log('📋 העתקת היסטוריה מסוננת ללוח...');
    
    // קבלת פילטרים פעילים
    const typeFilter = document.getElementById('historyFilter')?.value || '';
    const pageFilter = document.getElementById('pageFilter')?.value || '';
    const period = document.getElementById('historyPeriod')?.value || '24h';
    
    let log = '=== היסטוריית התראות מסוננת - TikTrack ===\n\n';
    log += `📅 תאריך: ${new Date().toLocaleString('he-IL')}\n`;
    log += `🔍 סינון: סוג=${typeFilter || 'כל ההתראות'}, עמוד=${pageFilter || 'כל העמודים'}, תקופה=${period}\n\n`;
    
    // טעינת היסטוריה גלובלית
    if (typeof window.loadGlobalNotificationHistory === 'function') {
      try {
        const globalHistory = await window.loadGlobalNotificationHistory();
      if (globalHistory && globalHistory.length > 0) {
        // סינון לפי זמן
        const now = new Date();
        let filteredHistory = globalHistory;
        
        if (period !== 'all') {
          const periodMs = getPeriodMs(period);
          const cutoffTime = new Date(now.getTime() - periodMs);
          filteredHistory = filteredHistory.filter(notification => 
            notification.time && new Date(notification.time) >= cutoffTime
          );
        }
        
        // סינון לפי סוג
        if (typeFilter) {
          filteredHistory = filteredHistory.filter(notification => notification.type === typeFilter);
        }
        
        // סינון לפי עמוד
        if (pageFilter) {
          filteredHistory = filteredHistory.filter(notification => notification.page === pageFilter);
        }
        
        // הוספת התראות מסוננות
        if (filteredHistory.length > 0) {
          filteredHistory.slice(0, 100).forEach((notification, index) => {
            const page = notification.page || 'לא ידוע';
            const time = notification.time ? new Date(notification.time).toLocaleString('he-IL') : 'לא ידוע';
            const typeIcon = getTypeIcon(notification.type);
            log += `${index + 1}. ${typeIcon} [${notification.type.toUpperCase()}] ${notification.title}: ${notification.message} | עמוד: ${page} | ${time}\n`;
          });
          
          if (filteredHistory.length > 100) {
            log += `... ועוד ${filteredHistory.length - 100} התראות\n`;
          }
        } else {
          log += 'אין התראות המתאימות לסינון הפעיל\n';
        }
      } else {
        log += 'אין היסטוריית התראות גלובלית\n';
      }
      } catch (error) {
        console.warn('⚠️ Error loading global notification history:', error);
        log += 'שגיאה בטעינת היסטוריה גלובלית\n';
      }
    } else {
      log += 'פונקציית טעינת היסטוריה גלובלית לא זמינה\n';
    }
    
    // העתקה ללוח
    navigator.clipboard.writeText(log).then(() => {
      if (typeof window.showSuccessNotification === 'function') {
        window.showSuccessNotification('הצלחה', 'היסטוריה מסוננת הועתקה ללוח בהצלחה!');
      } else {
        alert('היסטוריה מסוננת הועתקה ללוח בהצלחה!');
      }
      console.log('✅ היסטוריה מסוננת הועתקה ללוח');
    }).catch(err => {
      if (typeof window.showErrorNotification === 'function') {
        window.showErrorNotification('שגיאה', 'לא ניתן להעתיק ללוח: ' + err.message);
      } else {
        alert('שגיאה בהעתקה: ' + err.message);
      }
      console.error('❌ שגיאה בהעתקה ללוח:', err);
    });
    
  } catch (error) {
    console.error('❌ שגיאה בהעתקת היסטוריה מסוננת:', error);
    if (typeof window.showErrorNotification === 'function') {
      window.showErrorNotification('שגיאה', 'שגיאה בהעתקת היסטוריה מסוננת: ' + error.message);
    } else {
      alert('שגיאה בהעתקת היסטוריה מסוננת: ' + error.message);
    }
  }
}

// פונקציות עזר לסינון
function getPeriodMs(period) {
  switch (period) {
    case '1h': return 60 * 60 * 1000;
    case '24h': return 24 * 60 * 60 * 1000;
    case '7d': return 7 * 24 * 60 * 60 * 1000;
    case '30d': return 30 * 24 * 60 * 60 * 1000;
    default: return 24 * 60 * 60 * 1000;
  }
}

function getTypeIcon(type) {
  switch (type) {
    case 'success': return '✅';
    case 'error': return '❌';
    case 'warning': return '⚠️';
    case 'info': return 'ℹ️';
    default: return '🔔';
  }
}

// פונקציה להעתקת לוג מפורט עם כל הנתונים והסטטוס


// פונקציות גלובליות
// הגדרות התראות הועברו למערכת ההעדפות הגלובלית

// הגדרות התראות הועברו למערכת ההעדפות הגלובלית


// פונקציות גלובליות - קוראות לפונקציות של המחלקה
function clearHistory() {
  if (window.notificationsCenter) {
    window.notificationsCenter.clearHistory();
  }
}

function refreshNotifications() {
  if (window.notificationsCenter) {
    window.notificationsCenter.refreshNotifications();
  }
}

function filterHistory() {
  if (window.notificationsCenter) {
    window.notificationsCenter.filterHistory();
  }
}

// פונקציות בדיקת התראות - מעודכנות למערכת החדשה
function testSuccessNotification() {
  console.log('🧪 Testing success notification (New System)...');
  
  // בדיקה שהמערכת החדשה זמינה
  if (typeof window.showSuccessNotification === 'function') {
    window.showSuccessNotification('בדיקת הצלחה', 'זוהי הודעת הצלחה לבדיקה במערכת החדשה - הכל עובד תקין!', 4000, 'system');
  } else {
    console.error('❌ showSuccessNotification לא זמין - המערכת החדשה לא נטענה');
    // Fallback למקרה שהמערכת החדשה לא נטענה
    alert('מערכת ההתראות החדשה לא נטענה. בדוק את הטעינה של modules/core-systems.js');
  }
}

function testErrorNotification() {
  console.log('🧪 Testing error notification (New System)...');
  
  // בדיקה שהמערכת החדשה זמינה
  if (typeof window.showErrorNotification === 'function') {
    window.showErrorNotification('בדיקת שגיאה', 'זוהי הודעת שגיאה לבדיקה במערכת החדשה - הכל עובד תקין!', 6000, 'system');
  } else {
    console.error('❌ showErrorNotification לא זמין - המערכת החדשה לא נטענה');
    // Fallback למקרה שהמערכת החדשה לא נטענה
    alert('מערכת ההתראות החדשה לא נטענה. בדוק את הטעינה של modules/core-systems.js');
  }
}

function testWarningNotification() {
  console.log('🧪 Testing warning notification (New System)...');
  
  // בדיקה שהמערכת החדשה זמינה
  if (typeof window.showWarningNotification === 'function') {
    window.showWarningNotification('בדיקת אזהרה', 'זוהי הודעת אזהרה לבדיקה במערכת החדשה - הכל עובד תקין!', 5000, 'system');
  } else {
    console.error('❌ showWarningNotification לא זמין - המערכת החדשה לא נטענה');
    // Fallback למקרה שהמערכת החדשה לא נטענה
    alert('מערכת ההתראות החדשה לא נטענה. בדוק את הטעינה של modules/core-systems.js');
  }
}

function testInfoNotification() {
  console.log('🧪 Testing info notification (New System)...');
  
  // בדיקה שהמערכת החדשה זמינה
  if (typeof window.showInfoNotification === 'function') {
    window.showInfoNotification('בדיקת מידע', 'זוהי הודעת מידע לבדיקה במערכת החדשה - הכל עובד תקין!', 4000, 'system');
  } else {
    console.error('❌ showInfoNotification לא זמין - המערכת החדשה לא נטענה');
    // Fallback למקרה שהמערכת החדשה לא נטענה
    alert('מערכת ההתראות החדשה לא נטענה. בדוק את הטעינה של modules/core-systems.js');
  }
}

// בדיקת הודעות אישור - מעודכנת למערכת החדשה
function testConfirmationDialog() {
  console.log('🧪 Testing confirmation dialog (New System)...');
  console.log('🔍 showConfirmationDialog type:', typeof window.showConfirmationDialog);
  console.log('🔍 showConfirmationDialog function:', window.showConfirmationDialog);
  
  if (typeof window.showConfirmationDialog === 'function') {
    console.log('✅ Calling showConfirmationDialog...');
    try {
      window.showConfirmationDialog(
        'בדיקת אישור - מערכת חדשה',
        'האם אתה בטוח שברצונך לבצע את הפעולה הזו במערכת החדשה?',
        () => {
          console.log('✅ User confirmed');
          if (typeof window.showSuccessNotification === 'function') {
            window.showSuccessNotification('אישור', 'המשתמש אישר את הפעולה במערכת החדשה', 3000, 'system');
          } else {
            alert('המשתמש אישר את הפעולה');
          }
        },
        () => {
          console.log('❌ User cancelled');
          if (typeof window.showInfoNotification === 'function') {
            window.showInfoNotification('ביטול', 'המשתמש ביטל את הפעולה במערכת החדשה', 3000, 'system');
          } else {
            alert('המשתמש ביטל את הפעולה');
          }
        }
      );
      console.log('✅ showConfirmationDialog called successfully');
    } catch (error) {
      console.error('❌ Error calling showConfirmationDialog:', error);
    }
  } else {
    console.error('❌ showConfirmationDialog לא זמין - המערכת החדשה לא נטענה');
    alert('מערכת ההתראות החדשה לא נטענה. בדוק את הטעינה של modules/core-systems.js');
  }
}

// בדיקת מודל פרטים - מעודכנת למערכת החדשה
function testDetailsModal() {
  console.log('🧪 Testing details modal (New System)...');
  console.log('🔍 showDetailsModal type:', typeof window.showDetailsModal);
  console.log('🔍 showDetailsModal function:', window.showDetailsModal);
  
  if (typeof window.showDetailsModal === 'function') {
    console.log('✅ Calling showDetailsModal...');
    try {
      const detailsContent = `
        <div class="details-content">
          <h5>פרטי בדיקה - מערכת חדשה</h5>
          <p><strong>זמן:</strong> ${new Date().toLocaleString('he-IL')}</p>
          <p><strong>דף:</strong> ${window.location.pathname}</p>
          <p><strong>משתמש:</strong> בדיקה</p>
          <p><strong>סטטוס:</strong> פעיל במערכת החדשה</p>
          <p><strong>מערכת:</strong> New General Systems Architecture</p>
          <p><strong>גרסה:</strong> 2.0.0</p>
        </div>
      `;
      
      window.showDetailsModal('בדיקת מודל פרטים - מערכת חדשה', detailsContent);
      console.log('✅ showDetailsModal called successfully');
    } catch (error) {
      console.error('❌ Error calling showDetailsModal:', error);
    }
  } else {
    console.error('❌ showDetailsModal לא זמין - המערכת החדשה לא נטענה');
    alert('מערכת ההתראות החדשה לא נטענה. בדוק את הטעינה של modules/core-systems.js');
  }
}

// בדיקת הודעת שגיאה קריטית
function testCriticalErrorNotification() {
  console.log('🧪 Testing critical error notification...');
  console.log('🔍 showCriticalErrorNotification type:', typeof window.showCriticalErrorNotification);
  console.log('🔍 showCriticalErrorNotification function:', window.showCriticalErrorNotification);
  
  if (typeof window.showCriticalErrorNotification === 'function') {
    console.log('✅ Calling showCriticalErrorNotification...');
    try {
      const errorDetails = {
        source: 'test-function',
        function: 'testCriticalErrorNotification',
        line: '1620',
        stack: new Error().stack,
        additionalInfo: {
          testMode: true,
          timestamp: Date.now(),
          userAction: 'manual-test'
        }
      };
      
      window.showCriticalErrorNotification(
        'בדיקת שגיאה קריטית',
        'זוהי בדיקה של מערכת הודעות השגיאה הקריטית החדשה - הכל עובד תקין!',
        errorDetails,
        'system'
      );
      console.log('✅ showCriticalErrorNotification called successfully');
    } catch (error) {
      console.error('❌ Error calling showCriticalErrorNotification:', error);
    }
  } else {
    console.error('❌ showCriticalErrorNotification לא זמין');
  }
}

// דוגמה לשימוש במערכת החדשה
function demonstrateCriticalErrorUsage() {
  console.log('🧪 Demonstrating critical error usage...');
  
  // דוגמה 1: שגיאה פשוטה עם זיהוי אוטומטי
  if (typeof window.createCriticalError === 'function') {
    window.createCriticalError(
      'דוגמה לשגיאה פשוטה',
      'זוהי דוגמה לשגיאה עם זיהוי אוטומטי של מקור ופונקציה'
    );
  }
  
  // דוגמה 2: שגיאה עם פרטים נוספים
  if (typeof window.showCriticalErrorNotification === 'function') {
    const errorDetails = {
      source: 'demonstration',
      function: 'demonstrateCriticalErrorUsage',
      line: '1700',
      stack: new Error().stack,
      userAction: 'clicked-demo-button',
      additionalData: {
        userId: 123,
        sessionId: 'abc123',
        timestamp: Date.now()
      }
    };
    
    window.showCriticalErrorNotification(
      'דוגמה לשגיאה מפורטת',
      'זוהי דוגמה לשגיאה עם פרטים מפורטים כולל מידע משתמש',
      errorDetails,
      'system'
    );
  }
  
  // דוגמה 3: עטיפת פונקציה עם טיפול בשגיאות
  if (typeof window.withCriticalErrorHandling === 'function') {
    const riskyFunction = async function() {
      // פונקציה שעלולה להיכשל
      throw new Error('דוגמה לשגיאה בפונקציה');
    };
    
    const safeFunction = window.withCriticalErrorHandling(
      riskyFunction,
      'שגיאה בפונקציה מסוכנת',
      'הפונקציה riskyFunction נכשלה'
    );
    
    // הרצת הפונקציה הבטוחה
    safeFunction().catch(error => {
      console.log('הפונקציה נכשלה אבל השגיאה טופלה:', error.message);
    });
  }
}

// בדיקת הודעת שגיאה פשוטה (legacy mode)
function testSimpleErrorNotification() {
  console.log('🧪 Testing simple error notification (legacy mode)...');
  
  if (typeof window.showSimpleErrorNotification === 'function') {
    console.log('✅ Calling showSimpleErrorNotification...');
    try {
      window.showSimpleErrorNotification(
        'בדיקת שגיאה פשוטה',
        'זוהי בדיקה של הודעת שגיאה פשוטה (מצב legacy) - הכל עובד תקין!',
        4000,
        'system'
      );
      console.log('✅ showSimpleErrorNotification called successfully');
    } catch (error) {
      console.error('❌ Error calling showSimpleErrorNotification:', error);
    }
  } else {
    console.error('❌ showSimpleErrorNotification לא זמין');
  }
}

// בדיקת הודעת הצלחה סופית - מעודכנת למערכת החדשה
function testFinalSuccessNotification() {
  console.log('🧪 Testing final success notification (New System)...');
  
  if (typeof window.showFinalSuccessNotification === 'function') {
    console.log('✅ Calling showFinalSuccessNotification...');
    try {
      window.showFinalSuccessNotification(
        'תהליך הושלם בהצלחה - מערכת חדשה!',
        'הפעולה שביצעת הושלמה בהצלחה במערכת החדשה עם כל הפרטים המפורטים',
        {
          operation: 'test-operation-new-system',
          result: 'success',
          itemsProcessed: 42,
          duration: '2.5 seconds',
          timestamp: new Date().toISOString(),
          system: 'New General Systems Architecture',
          version: '2.0.0'
        },
        'system'
      );
      console.log('✅ showFinalSuccessNotification called successfully');
    } catch (error) {
      console.error('❌ Error calling showFinalSuccessNotification:', error);
    }
  } else {
    console.error('❌ showFinalSuccessNotification לא זמין - המערכת החדשה לא נטענה');
    alert('מערכת ההתראות החדשה לא נטענה. בדוק את הטעינה של modules/core-systems.js');
  }
}


async function copyDetailedLog() {
  try {
    const detailedLog = await generateDetailedLog();
    if (detailedLog) {
      await navigator.clipboard.writeText(detailedLog);
      if (typeof window.showSuccessNotification === 'function') {
        window.showSuccessNotification('לוג מפורט הועתק ללוח', 'הלוג המפורט הועתק ללוח בהצלחה במערכת החדשה', 3000, 'system');
      } else {
        alert('לוג מפורט הועתק ללוח');
      }
    } else {
      if (typeof window.showWarningNotification === 'function') {
        window.showWarningNotification('אין לוג להעתקה', 'לא נמצא לוג להעתקה במערכת החדשה', 3000, 'system');
      } else {
        alert('אין לוג להעתקה');
      }
    }
  } catch (err) {
    console.error('שגיאה בהעתקה:', err);
    if (typeof window.showErrorNotification === 'function') {
      window.showErrorNotification('שגיאה בהעתקת הלוג', 'שגיאה בהעתקת הלוג במערכת החדשה: ' + err.message, 5000, 'system');
    } else {
      alert('שגיאה בהעתקת הלוג: ' + err.message);
    }
  }
}

async function copyNotificationsToClipboard() {
  try {
    if (typeof window.getGlobalNotifications === 'function') {
      const notifications = await window.getGlobalNotifications();
      if (notifications && notifications.length > 0) {
        let logText = '=== היסטוריית התראות TikTrack ===\n';
        logText += `זמן יצירה: ${new Date().toLocaleString('he-IL')}\n`;
        logText += `סה"כ התראות: ${notifications.length}\n\n`;
        
        notifications.forEach((notification, index) => {
          logText += `${index + 1}. [${notification.type?.toUpperCase() || 'INFO'}] ${notification.title || 'ללא כותרת'}\n`;
          logText += `   הודעה: ${notification.message || 'ללא הודעה'}\n`;
          logText += `   זמן: ${new Date(notification.timestamp).toLocaleString('he-IL')}\n`;
          if (notification.category) {
            logText += `   קטגוריה: ${notification.category}\n`;
          }
          logText += '\n';
        });
        
        await navigator.clipboard.writeText(logText);
        window.showSuccessNotification('היסטוריית התראות הועתקה ללוח');
      } else {
        window.showInfoNotification('אין התראות להעתקה');
      }
    } else {
      window.showErrorNotification('פונקציית איסוף התראות לא זמינה');
    }
  } catch (error) {
    console.error('שגיאה בהעתקת התראות:', error);
    window.showErrorNotification('שגיאה בהעתקת התראות');
  }
}

function toggleSection() {
    const topSection = document.querySelector('.top-section .section-body');
    if (topSection) {
        if (topSection.style.display === 'none') {
            topSection.style.display = '';
            console.log('✅ Top section expanded');
        } else {
            topSection.style.display = 'none';
            console.log('✅ Top section collapsed');
        }
    } else {
        console.warn('❌ Top section not found');
    }
}


// toggleSection function removed - using global version from ui-utils.js

// ייצוא פונקציות ל-window scope
window.copyNotificationsToClipboard = copyNotificationsToClipboard;
window.copyFilteredHistoryToClipboard = copyFilteredHistoryToClipboard;
// window.copyDetailedLog export removed - using global version from system-management.js
window.clearHistory = clearHistory;
window.refreshNotifications = refreshNotifications;
window.filterHistory = filterHistory;
// הגדרות התראות הועברו למערכת ההעדפות הגלובלית
window.testSuccessNotification = testSuccessNotification;
window.testErrorNotification = testErrorNotification;
window.testWarningNotification = testWarningNotification;
window.testInfoNotification = testInfoNotification;

// ייצוא פונקציה להוספת התראות
window.addNotification = function(type, title, message, time = 'now') {
  if (window.notificationsCenter && typeof window.notificationsCenter.addNotification === 'function') {
    window.notificationsCenter.addNotification(type, title, message, time);
  } else {
    console.warn('❌ מרכז התראות לא זמין להוספת התראה');
  }
};


// אתחול
// אתחול דרך מערכת האתחול המאוחדת
window.loadNotifications = async function() {
    try {
        console.log('📬 Loading Notifications Center...');
        
        // יצירת מופע מרכז התראות
        window.notificationsCenter = new NotificationsCenter();
        await window.notificationsCenter.init();
        console.log('✅ Notifications Center loaded successfully');
    } catch (error) {
        console.error('❌ Error loading Notifications Center:', error);
        // המשך גם אם יש שגיאה
    }
};

// אתחול ישיר (גיבוי) - רק אם המערכת המאוחדת לא עובדת
// הוסר - המערכת המאוחדת מטפלת באתחול
// document.addEventListener('DOMContentLoaded', () => {
//   console.log('🚀 טעינת דף מרכז התראות... (1.0.9 - Fixed + Debug + Settings + Filter + Stats + Layout - Live Removed + Settings Fix + AutoRefresh Fix)');
//
//   // המתן למערכת המאוחדת
//   setTimeout(() => {
//     if (!window.notificationsCenter) {
//       console.log('⚠️ Unified system not available, using direct initialization');
//       window.loadNotifications();
//     }
//     
//     // טעינת נתוני סקירה כללית
//     if (typeof window.loadOverviewData === 'function') {
//       window.loadOverviewData();
//     }
//   }, 2000);

  // בדיקת זמינות פונקציות
  console.log('🔍 בדיקת זמינות פונקציות:');
  console.log('🔍 testSuccessNotification:', typeof testSuccessNotification);
  console.log('🔍 testErrorNotification:', typeof testErrorNotification);
  console.log('🔍 testWarningNotification:', typeof testWarningNotification);
  console.log('🔍 testInfoNotification:', typeof testInfoNotification);
  console.log('🔍 window.testSuccessNotification:', typeof window.testSuccessNotification);
  console.log('🔍 window.testErrorNotification:', typeof window.testErrorNotification);
  console.log('🔍 window.testWarningNotification:', typeof window.testWarningNotification);
  console.log('🔍 window.testInfoNotification:', typeof window.testInfoNotification);

  // Make functions globally available
  window.copyNotificationsToClipboard = copyNotificationsToClipboard;
  window.copyDetailedLog = copyDetailedLog;
  window.testSuccessNotification = testSuccessNotification;
  window.testErrorNotification = testErrorNotification;
  window.testWarningNotification = testWarningNotification;
  window.testInfoNotification = testInfoNotification;
  // window.toggleSection removed - using global version from ui-utils.js
  // window.toggleAllSections export removed - using global version from ui-utils.js
  // window.toggleSection export removed - using global version from ui-utils.js

  console.log('✅ דף מרכז התראות נטען בהצלחה (1.0.9 - Fixed + Debug + Settings + Filter + Stats + Layout - Live Removed + Settings Fix + AutoRefresh Fix)');

/**
 * Generate detailed log for Notifications Center
 */
async function generateDetailedLog() {
    const timestamp = new Date().toLocaleString('he-IL');
    const log = [];

    log.push('=== לוג מפורט - מרכז התראות TikTrack (מערכת חדשה) ===');
    log.push(`זמן יצירה: ${timestamp}`);
    log.push(`עמוד: ${window.location.href}`);
    log.push(`מערכת: New General Systems Architecture v2.0.0`);
    log.push('');
    
    // סטטוס כללי
    log.push('--- סטטוס כללי ---');
    const topSection = document.querySelector('.top-section .section-body');
    const isTopOpen = topSection && topSection.style.display !== 'none';
    log.push(`סקשן עליון: ${isTopOpen ? 'פתוח' : 'סגור'}`);
    
    // טעינת נתונים מהלוג המאוחד
    let allNotifications = [];
    let totalCount = 0;
    
    try {
        if (window.UnifiedLogAPI) {
            console.log('🔍 UnifiedLogAPI זמין, מנסה לטעון נתונים...');
            const logData = await window.UnifiedLogAPI.getLogData('notificationHistory');
            if (logData && Array.isArray(logData)) {
                allNotifications = logData;
                totalCount = logData.length;
                console.log('📊 לוג מפורט - נטענו מהלוג המאוחד:', totalCount, 'התראות');
            } else {
                console.log('📊 לוג מפורט - אין נתונים בלוג המאוחד');
            }
        } else {
            console.log('🔍 UnifiedLogAPI לא זמין');
        }
    } catch (error) {
        console.warn('שגיאה בטעינת נתונים מהלוג המאוחד ללוג מפורט:', error);
    }
    
    // Fallback ל-localStorage אם הלוג המאוחד לא זמין
    if (allNotifications.length === 0) {
        try {
            let savedHistory = null;
            if (window.UnifiedCacheManager && window.UnifiedCacheManager.isInitialized()) {
                savedHistory = await window.UnifiedCacheManager.get('tiktrack_global_notifications_history');
            } else {
                savedHistory = localStorage.getItem('tiktrack_global_notifications_history'); // fallback
            }
            
            if (savedHistory) {
                allNotifications = typeof savedHistory === 'string' ? JSON.parse(savedHistory) : savedHistory;
                totalCount = allNotifications.length;
                console.log('📊 לוג מפורט - נטענו מ-localStorage:', totalCount, 'התראות');
            } else {
                console.log('📊 לוג מפורט - אין נתונים ב-localStorage');
            }
        } catch (e) {
            console.warn('שגיאה בטעינה מ-localStorage:', e);
        }
    }
    
    // Fallback נוסף ל-notificationsCenter
    if (allNotifications.length === 0 && window.notificationsCenter && window.notificationsCenter.history) {
        allNotifications = window.notificationsCenter.history;
        totalCount = allNotifications.length;
        console.log('📊 לוג מפורט - נטענו מ-notificationsCenter:', totalCount, 'התראות');
    }
    
    // סטטיסטיקות התראות אמיתיות מהלוג המלא
    log.push('--- סטטיסטיקות התראות ---');
    if (allNotifications.length > 0) {
        const successCount = allNotifications.filter(n => n.type === 'success').length;
        const errorCount = allNotifications.filter(n => n.type === 'error').length;
        const warningCount = allNotifications.filter(n => n.type === 'warning').length;
        const infoCount = allNotifications.filter(n => n.type === 'info').length;
        
        log.push(`סה"כ התראות: ${totalCount}`);
        log.push(`הודעות הצלחה: ${successCount}`);
        log.push(`שגיאות: ${errorCount}`);
        log.push(`אזהרות: ${warningCount}`);
        log.push(`הודעות מידע: ${infoCount}`);
        
        // סטטיסטיקות לפי קטגוריות
        const categories = {};
        allNotifications.forEach(n => {
            const category = n.category || 'general';
            categories[category] = (categories[category] || 0) + 1;
        });
        
        if (Object.keys(categories).length > 0) {
            log.push('');
            log.push('סטטיסטיקות לפי קטגוריות:');
            Object.entries(categories).forEach(([category, count]) => {
                log.push(`  ${category}: ${count}`);
            });
        }
    } else {
        log.push('היסטוריית התראות לא זמינה');
        log.push('בדיקת מקורות נתונים:');
        log.push(`  UnifiedLogAPI זמין: ${window.UnifiedLogAPI ? 'כן' : 'לא'}`);
        let localStorageAvailable = false;
        if (window.UnifiedCacheManager && window.UnifiedCacheManager.isInitialized()) {
            const data = await window.UnifiedCacheManager.get('tiktrack_global_notifications_history');
            localStorageAvailable = data !== null;
        } else {
            localStorageAvailable = localStorage.getItem('tiktrack_global_notifications_history') !== null;
        }
        log.push(`  localStorage זמין: ${localStorageAvailable ? 'כן' : 'לא'}`);
        log.push(`  notificationsCenter זמין: ${window.notificationsCenter ? 'כן' : 'לא'}`);
        if (window.notificationsCenter) {
            log.push(`  notificationsCenter.history: ${window.notificationsCenter.history ? window.notificationsCenter.history.length : 'לא קיים'}`);
        }
    }
    
    log.push('');
    
    // סטטוס חיבור
    log.push('--- סטטוס מערכת ---');
    log.push(`סטטוס מערכת: פעיל במערכת החדשה`);
    log.push(`מערכת: New General Systems Architecture v2.0.0`);
    log.push(`מקור נתונים: ${window.UnifiedLogAPI ? 'לוג מאוחד' : 'localStorage'}`);
    log.push(`זמן עדכון: ${new Date().toLocaleString('he-IL')}`);
    
    // סקירה כללית
    log.push('--- סקירה כללית ---');
    if (allNotifications.length > 0) {
        const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000);
        const newMessages = allNotifications.filter(n => {
            const notificationTime = new Date(n.time || n.timestamp || n.createdAt);
            return notificationTime > oneHourAgo;
        }).length;
        
        log.push(`התראות פעילות: ${totalCount}`);
        log.push(`הודעות חדשות (שעה אחרונה): ${newMessages}`);
        
        if (allNotifications.length > 0) {
            const lastNotification = allNotifications[0];
            const lastTime = lastNotification.time || lastNotification.timestamp || lastNotification.createdAt;
            log.push(`עדכון אחרון: ${new Date(lastTime).toLocaleString('he-IL')}`);
        }
    }
    log.push(`סטטוס: פעיל במערכת החדשה`);

    // היסטוריית התראות (10 האחרונות)
    log.push('--- היסטוריית התראות (10 האחרונות) ---');
    if (allNotifications.length > 0) {
        allNotifications.slice(0, 10).forEach((notification, index) => {
            const notificationTime = notification.time || notification.timestamp || notification.createdAt;
            const timeStr = new Date(notificationTime).toLocaleString('he-IL');
            log.push(`${index + 1}. [${notification.type?.toUpperCase() || 'INFO'}] ${notification.title || 'ללא כותרת'} - ${timeStr}`);
        });
        if (allNotifications.length > 10) {
            log.push(`... ועוד ${allNotifications.length - 10} התראות`);
        }
    } else {
        log.push('אין היסטוריית התראות');
    }
    
    // פילטרים פעילים
    log.push('--- פילטרים פעילים ---');
    log.push(`פילטר סוג: ${document.getElementById('historyFilter')?.value || 'כל ההתראות'}`);
    log.push(`פילטר עמוד: ${document.getElementById('pageFilter')?.value || 'כל העמודים'}`);
    
    return log.join('\n');
}

/**
 * Copy detailed log to clipboard
 */

// ייצוא לגלובל scope
// window.copyDetailedLog export removed - using global version from system-management.js

// ===== UNIFIED LOG SYSTEM INTEGRATION =====

/**
 * Activate unified log system
 */
async function activateUnifiedLogSystem() {
    try {
        console.log('🚀 Activating Unified Log System...');
        
        // Show the unified logs section
        const unifiedLogsSection = document.querySelector('[data-section="unified-logs"]');
        if (unifiedLogsSection) {
            unifiedLogsSection.style.display = 'block';
            // Scroll to the section
            unifiedLogsSection.scrollIntoView({ behavior: 'smooth' });
        }
        
        // Initialize the API if not already initialized
        if (window.UnifiedLogAPI && !window.UnifiedLogAPI.initialized) {
            await window.UnifiedLogAPI.initialize();
        }
        
        // Show notification
        if (window.showNotification) {
            window.showNotification('מערכת הלוגים החדשה הופעלה!', 'success');
        }
        
        console.log('✅ Unified Log System activated successfully');
    } catch (error) {
        console.error('❌ Failed to activate Unified Log System:', error);
        if (window.showNotification) {
            window.showNotification('שגיאה בהפעלת מערכת הלוגים החדשה: ' + error.message, 'error');
        }
    }
}

/**
 * Show notification log in new system
 */
async function showNotificationLogNew() {
    try {
        console.log('📊 Showing notification log in new system...');
        
        await window.showNotificationLog('unified-logs-container', {
            displayConfig: 'default',
            autoRefresh: true,
            refreshInterval: 10000
        });
        
        if (window.showNotification) {
            window.showNotification('לוג התראות נטען במערכת החדשה', 'success');
        }
    } catch (error) {
        console.error('❌ Failed to show notification log:', error);
        if (window.showNotification) {
            window.showNotification('שגיאה בטעינת לוג התראות: ' + error.message, 'error');
        }
    }
}

/**
 * Show system logs in new system
 */
async function showSystemLogsNew() {
    try {
        console.log('📊 Showing system logs in new system...');
        
        await window.showSystemLogs('unified-logs-container', {
            displayConfig: 'default',
            autoRefresh: false
        });
        
        if (window.showNotification) {
            window.showNotification('לוגים מערכתיים נטענו במערכת החדשה', 'success');
        }
    } catch (error) {
        console.error('❌ Failed to show system logs:', error);
        if (window.showNotification) {
            window.showNotification('שגיאה בטעינת לוגים מערכתיים: ' + error.message, 'error');
        }
    }
}

/**
 * Show error reports in new system
 */
async function showErrorReportsNew() {
    try {
        console.log('📊 Showing error reports in new system...');
        
        await window.showErrorReports('unified-logs-container', {
            displayConfig: 'default',
            autoRefresh: false
        });
        
        if (window.showNotification) {
            window.showNotification('דוחות שגיאות נטענו במערכת החדשה', 'success');
        }
    } catch (error) {
        console.error('❌ Failed to show error reports:', error);
        if (window.showNotification) {
            window.showNotification('שגיאה בטעינת דוחות שגיאות: ' + error.message, 'error');
        }
    }
}

/**
 * Export all available logs
 */
async function exportAllLogs() {
    try {
        console.log('📊 Exporting all logs...');
        
        // Show export options modal
        const modal = document.createElement('div');
        modal.className = 'modal fade';
        modal.innerHTML = `
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">ייצוא כל הלוגים</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <p>בחר פורמט ייצוא:</p>
                        <div class="d-grid gap-2">
                            <button class="btn btn-success export-btn" data-format="csv">
                                <i class="fas fa-file-csv"></i> ייצוא CSV
                            </button>
                            <button class="btn btn-info export-btn" data-format="json">
                                <i class="fas fa-file-code"></i> ייצוא JSON
                            </button>
                            <button class="btn btn-warning export-btn" data-format="clipboard">
                                <i class="fas fa-clipboard"></i> העתקה ללוח
                            </button>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">סגור</button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        // Show modal
        const bsModal = new bootstrap.Modal(modal);
        bsModal.show();
        
        // Export buttons
        const exportBtns = modal.querySelectorAll('.export-btn');
        exportBtns.forEach(btn => {
            btn.addEventListener('click', async () => {
                const format = btn.dataset.format;
                
                try {
                    // Export notification history as example
                    await window.exportLog('notificationHistory', format);
                    
                    if (window.showNotification) {
                        window.showNotification(`הנתונים יוצאו בהצלחה ב-${format.toUpperCase()}`, 'success');
                    }
                } catch (error) {
                    console.error(`❌ Failed to export as ${format}:`, error);
                    if (window.showNotification) {
                        window.showNotification(`שגיאה בייצוא ${format}: ` + error.message, 'error');
                    }
                }
                
                bsModal.hide();
            });
        });
        
        // Cleanup on hide
        modal.addEventListener('hidden.bs.modal', () => {
            document.body.removeChild(modal);
        });
        
    } catch (error) {
        console.error('❌ Failed to export all logs:', error);
        if (window.showNotification) {
            window.showNotification('שגיאה בייצוא הלוגים: ' + error.message, 'error');
        }
    }
}

/**
 * Load notification log automatically on page load - Updated for New System
 */
async function loadNotificationLog() {
    try {
        console.log('📊 Loading notification log automatically (New System)...');
        
        // בדיקה שהמערכת החדשה זמינה
        if (typeof window.showNotificationLog === 'function') {
            await window.showNotificationLog('notification-log-container', {
                displayConfig: 'default',
                autoRefresh: true,
                refreshInterval: 10000
            });
            console.log('✅ Notification log loaded successfully with new system');
        } else {
            console.warn('⚠️ showNotificationLog not available, using fallback');
            // Fallback למקרה שהמערכת החדשה לא נטענה
            const container = document.getElementById('notification-log-container');
            if (container) {
                container.innerHTML = `
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle"></i>
                        מערכת הלוגים החדשה לא נטענה. בדוק את הטעינה של modules/core-systems.js
                    </div>
                `;
            }
        }
    } catch (error) {
        console.error('❌ Failed to load notification log:', error);
        // Fallback במקרה של שגיאה
        const container = document.getElementById('notification-log-container');
        if (container) {
            container.innerHTML = `
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i>
                    שגיאה בטעינת לוג התראות: ${error.message}
                </div>
            `;
        }
    }
}

/**
 * Test the new system with sample data - Updated for New System
 */
async function testUnifiedLogSystem() {
    try {
        console.log('🧪 Testing Unified Log System (New System)...');
        
        // בדיקה שהמערכת החדשה זמינה
        if (typeof window.showSuccessNotification !== 'function') {
            console.error('❌ New notification system not available');
            alert('מערכת ההתראות החדשה לא נטענה. בדוק את הטעינה של modules/core-systems.js');
            return;
        }
        
        // Generate some test notifications
        const testNotifications = [
            { type: 'success', title: 'בדיקה', message: 'התראה חדשה במערכת החדשה v2.0.0' },
            { type: 'info', title: 'מידע', message: 'זהו לוג מידע במערכת החדשה v2.0.0' },
            { type: 'warning', title: 'אזהרה', message: 'זהו לוג אזהרה במערכת החדשה v2.0.0' },
            { type: 'error', title: 'שגיאה', message: 'זהו לוג שגיאה במערכת החדשה v2.0.0' }
        ];
        
        // Show test notifications using new system
        for (const notification of testNotifications) {
            if (notification.type === 'success' && window.showSuccessNotification) {
                window.showSuccessNotification(notification.title, notification.message, 3000, 'system');
            } else if (notification.type === 'info' && window.showInfoNotification) {
                window.showInfoNotification(notification.title, notification.message, 3000, 'system');
            } else if (notification.type === 'warning' && window.showWarningNotification) {
                window.showWarningNotification(notification.title, notification.message, 3000, 'system');
            } else if (notification.type === 'error' && window.showErrorNotification) {
                window.showErrorNotification(notification.title, notification.message, 3000, 'system');
            }
            // Wait a bit between notifications
            await new Promise(resolve => setTimeout(resolve, 500));
        }
        
        // Wait a moment then show the notification log
        setTimeout(async () => {
            await loadNotificationLog();
        }, 1000);
        
        if (window.showSuccessNotification) {
            window.showSuccessNotification('בדיקת המערכת החדשה הושלמה!', 'בדיקת המערכת החדשה v2.0.0 הושלמה בהצלחה!', 4000, 'system');
        }
        
    } catch (error) {
        console.error('❌ Failed to test Unified Log System:', error);
        if (window.showErrorNotification) {
            window.showErrorNotification('שגיאה בבדיקת המערכת', 'שגיאה בבדיקת המערכת החדשה: ' + error.message, 5000, 'system');
        } else {
            alert('שגיאה בבדיקת המערכת: ' + error.message);
        }
    }
}

// Export functions to global scope
window.activateUnifiedLogSystem = activateUnifiedLogSystem;
window.showNotificationLogNew = showNotificationLogNew;
window.showSystemLogsNew = showSystemLogsNew;
window.showErrorReportsNew = showErrorReportsNew;
window.exportAllLogs = exportAllLogs;
window.testUnifiedLogSystem = testUnifiedLogSystem;
window.loadNotificationLog = loadNotificationLog;
window.initializeNotificationsCenter = initializeNotificationsCenter;

/**
 * Refresh notifications data - global function for button - Updated for New System
 */
async function refreshNotificationsData() {
    try {
        if (window.notificationsCenter) {
            await window.notificationsCenter.refreshNotifications();
            if (typeof window.showSuccessNotification === 'function') {
                window.showSuccessNotification('נתוני התראות רוענו בהצלחה', 'נתוני התראות רוענו בהצלחה במערכת החדשה', 3000, 'system');
            } else {
                alert('נתוני התראות רוענו בהצלחה');
            }
        } else {
            console.warn('Notifications center not initialized');
            if (typeof window.showWarningNotification === 'function') {
                window.showWarningNotification('מרכז התראות לא מאותחל', 'מרכז התראות לא מאותחל במערכת החדשה', 3000, 'system');
            } else {
                alert('מרכז התראות לא מאותחל');
            }
        }
    } catch (error) {
        console.error('Error refreshing notifications data:', error);
        if (typeof window.showErrorNotification === 'function') {
            window.showErrorNotification('שגיאה ברענון נתונים', 'שגיאה ברענון נתונים במערכת החדשה: ' + error.message, 5000, 'system');
        } else {
            alert('שגיאה ברענון נתונים: ' + error.message);
        }
    }
}

window.refreshNotificationsData = refreshNotificationsData;

// ===== OVERVIEW SECTION FUNCTIONS =====

// Duplicate function removed - using the one at the top of the file

/**
 * Load preferences overview
 */
async function loadPreferencesOverview() {
  try {
    const container = document.getElementById('preferencesOverview');
    if (!container) return;

    // Get notification preferences from the correct group
    // Get preferences from the system using built-in function
    let preferences = {};
    if (typeof window.getGroupPreferences === 'function') {
      try {
        const result = await window.getGroupPreferences('notification_settings');
        if (result && result.success && result.data && result.data.preferences) {
          preferences = result.data.preferences;
        } else {
          console.warn('Failed to get notification preferences from system');
        }
      } catch (error) {
        console.error('Error loading notification preferences:', error);
      }
    }

    // Get the most important notification preferences only - organized like preferences page
    const basicSettings = [
      { key: 'enableNotifications', title: 'הפעל התראות', type: 'boolean' },
      { key: 'notificationPopup', title: 'חלון קופץ התראות', type: 'boolean' },
      { key: 'notificationSound', title: 'צליל התראות', type: 'boolean' },
      { key: 'notificationDuration', title: 'משך זמן הצגת התראה (שניות)', type: 'integer' },
      { key: 'enableRealtimeNotifications', title: 'התראות בזמן אמת', type: 'boolean' },
      { key: 'enableSystemEventNotifications', title: 'התראות על אירועי מערכת', type: 'boolean' },
      { key: 'notifyOnTradeExecuted', title: 'התראה על ביצוע עסקה', type: 'boolean' },
      { key: 'notifyOnStopLoss', title: 'התראה על stop loss', type: 'boolean' }
    ];

    const notificationCategories = [
      { key: 'notifications_system_enabled', title: 'התראות מערכת', type: 'boolean' },
      { key: 'notifications_business_enabled', title: 'התראות עסקיות', type: 'boolean' },
      { key: 'notifications_ui_enabled', title: 'התראות ממשק משתמש', type: 'boolean' },
      { key: 'notifications_development_enabled', title: 'התראות פיתוח', type: 'boolean' },
      { key: 'notifications_performance_enabled', title: 'התראות ביצועים', type: 'boolean' }
    ];

    const consoleLogs = [
      { key: 'console_logs_system_enabled', title: 'לוגים מערכתיים', type: 'boolean' },
      { key: 'console_logs_business_enabled', title: 'לוגים עסקיים', type: 'boolean' },
      { key: 'console_logs_ui_enabled', title: 'לוגים ממשק משתמש', type: 'boolean' },
      { key: 'console_logs_development_enabled', title: 'לוגים פיתוח', type: 'boolean' },
      { key: 'console_logs_performance_enabled', title: 'לוגים ביצועים', type: 'boolean' }
    ];

    let html = '<div class="preferences-list">';
    
    // הגדרות בסיסיות
    html += '<div class="mb-4">';
    html += '<h6 class="text-primary mb-3">הגדרות בסיסיות:</h6>';
    basicSettings.forEach(item => {
      const value = preferences[item.key];
      const displayValue = item.type === 'boolean' ? 
        (value === true || value === 'true' ? '✅ פעיל' : '❌ כבוי') :
        (value || 'לא מוגדר');
      
      html += `
        <div class="preference-item d-flex justify-content-between align-items-center p-2 border-bottom">
          <span class="preference-title">${item.title}</span>
          <span class="preference-value ${item.type === 'boolean' ? (value === true || value === 'true' ? 'text-success' : 'text-danger') : 'text-info'}">${displayValue}</span>
        </div>
      `;
    });
    html += '</div>';

    // קטגוריות התראות
    html += '<div class="row">';
    html += '<div class="col-md-6">';
    html += '<h6 class="text-primary mb-3">התראות מערכת:</h6>';
    notificationCategories.forEach(item => {
      const value = preferences[item.key];
      const displayValue = item.type === 'boolean' ? 
        (value === true || value === 'true' ? '✅ פעיל' : '❌ כבוי') :
        (value || 'לא מוגדר');
      
      html += `
        <div class="preference-item d-flex justify-content-between align-items-center p-2 border-bottom">
          <span class="preference-title">${item.title}</span>
          <span class="preference-value ${item.type === 'boolean' ? (value === true || value === 'true' ? 'text-success' : 'text-danger') : 'text-info'}">${displayValue}</span>
        </div>
      `;
    });
    html += '</div>';

    // לוגים לקונסול
    html += '<div class="col-md-6">';
    html += '<h6 class="text-success mb-3">לוגים לקונסול:</h6>';
    consoleLogs.forEach(item => {
      const value = preferences[item.key];
      const displayValue = item.type === 'boolean' ? 
        (value === true || value === 'true' ? '✅ פעיל' : '❌ כבוי') :
        (value || 'לא מוגדר');
      
      html += `
        <div class="preference-item d-flex justify-content-between align-items-center p-2 border-bottom">
          <span class="preference-title">${item.title}</span>
          <span class="preference-value ${item.type === 'boolean' ? (value === true || value === 'true' ? 'text-success' : 'text-danger') : 'text-info'}">${displayValue}</span>
        </div>
      `;
    });
    html += '</div>';
    html += '</div>';

    container.innerHTML = html;
    console.log('✅ Preferences overview loaded with correct data');
  } catch (error) {
    console.error('❌ Error loading preferences overview:', error);
  }
}

/**
 * Load category statistics
 */
async function loadCategoryStats() {
  try {
    const container = document.getElementById('categoryStats');
    if (!container) return;

    // Get statistics from the notification system
    let stats = { success: 0, error: 0, warning: 0, info: 0, total: 0 };
    
    if (window.notificationsCenter && window.notificationsCenter.stats) {
      stats = window.notificationsCenter.stats;
    }

    const categories = [
      { name: 'success', title: 'הצלחה', icon: 'fas fa-check-circle', color: '#28a745' },
      { name: 'error', title: 'שגיאה', icon: 'fas fa-times-circle', color: '#dc3545' },
      { name: 'warning', title: 'אזהרה', icon: 'fas fa-exclamation-triangle', color: '#ffc107' },
      { name: 'info', title: 'מידע', icon: 'fas fa-info-circle', color: '#17a2b8' }
    ];

    let html = '<div class="row">';
    categories.forEach(category => {
      const count = stats[category.name] || 0;
      const percentage = stats.total > 0 ? Math.round((count / stats.total) * 100) : 0;
      
      html += `
        <div class="col-md-3 col-sm-6 mb-3">
          <div class="stat-card text-center p-3 border rounded">
            <i class="${category.icon} fa-2x mb-2" style="color: ${category.color};"></i>
            <h4 class="mb-1" style="color: ${category.color};">${count.toLocaleString()}</h4>
            <p class="mb-1 text-muted">${category.title}</p>
            <small class="text-muted">${percentage}% מהסך הכל</small>
          </div>
        </div>
      `;
    });
    html += '</div>';

    // Add total statistics
    html += `
      <div class="row mt-3">
        <div class="col-12">
          <div class="total-stats text-center p-3 bg-light border rounded">
            <h5 class="mb-1">סך הכל: ${stats.total.toLocaleString()} הודעות</h5>
            <small class="text-muted">עדכון אחרון: ${new Date().toLocaleString('he-IL')}</small>
          </div>
        </div>
      </div>
    `;

    container.innerHTML = html;
    console.log('✅ Category statistics loaded');
  } catch (error) {
    console.error('❌ Error loading category statistics:', error);
  }
}

// Functions moved to top of file for early access

console.log('📊 Unified Log System integration loaded successfully');
