/**
 * Preferences System - Frontend JavaScript
 * =======================================
 * 
 * מערכת העדפות - JavaScript לממשק המשתמש
 * 
 * @version 1.0.0
 * @lastUpdated January 2025
 * @author TikTrack Development Team
 */

// ===== GLOBAL PREFERENCES SYSTEM =====

// Global preferences cache - Updated to use Unified Cache Manager
window.preferencesCache = {
    data: {},
    timestamp: null,
    ttl: 24 * 60 * 60 * 1000, // 24 hours in milliseconds
    isValid: function() {
        if (!this.timestamp) return false;
        return (Date.now() - this.timestamp) < this.ttl;
    },
    set: async function(data) {
        this.data = data;
        this.timestamp = Date.now();
        
        // שמירה במטמון מאוחד
        if (window.UnifiedCacheManager && window.UnifiedCacheManager.initialized) {
            await window.UnifiedCacheManager.save('user-preferences', data, {
                syncToBackend: true
            });
        } else if (window.UnifiedCacheManager && !window.UnifiedCacheManager.initialized) {
            console.warn('⚠️ UnifiedCacheManager not initialized, saving to localStorage only');
        }
    },
    get: async function() {
        if (this.isValid()) return this.data;
        
        // טעינה ממטמון מאוחד
        if (window.UnifiedCacheManager && window.UnifiedCacheManager.initialized) {
            const cachedData = await window.UnifiedCacheManager.get('user-preferences', {
                fallback: () => this.data
            });
            if (cachedData) {
                this.data = cachedData;
                this.timestamp = Date.now();
                return cachedData;
            }
        }
        
        return null;
    },
    clear: async function() {
        this.data = {};
        this.timestamp = null;
        
        // ניקוי ממטמון מאוחד
        if (window.UnifiedCacheManager && window.UnifiedCacheManager.initialized) {
            await window.UnifiedCacheManager.remove('user-preferences');
        }
    }
};

// ===== PAGINATION PREFERENCES =====

/**
 * קבלת העדפת גודל עמוד לטבלאות
 * @param {string} tableType - סוג הטבלה (ברירת מחדל: 'default')
 * @returns {Promise<number>} - מספר רשומות לעמוד
 */
window.getPaginationSize = async function(tableType = 'default') {
    try {
        const preferenceName = `pagination_size_${tableType}`;
        const size = await window.getPreference(preferenceName);
        return size || 25; // ברירת מחדל: 25 רשומות לעמוד
    } catch (error) {
        console.warn('Failed to get pagination size preference, using default:', error);
        return 25;
    }
};

/**
 * שמירת העדפת גודל עמוד לטבלאות
 * @param {string} tableType - סוג הטבלה
 * @param {number} size - מספר רשומות לעמוד
 * @returns {Promise<boolean>} - האם השמירה הצליחה
 */
window.setPaginationSize = async function(tableType = 'default', size = 25) {
    try {
        const preferenceName = `pagination_size_${tableType}`;
        return await window.savePreference(preferenceName, size);
    } catch (error) {
        console.error('Failed to set pagination size preference:', error);
        return false;
    }
};

// ===== CORE ACCESS FUNCTIONS =====

/**
 * קבלת העדפה בודדת
 * @param {string} preferenceName - שם ההעדפה
 * @param {number} userId - מזהה משתמש (ברירת מחדל: 1)
 * @param {number} profileId - מזהה פרופיל (אופציונלי)
 * @returns {Promise<any>} - ערך ההעדפה
 */
window.getPreference = async function(preferenceName, userId = null, profileId = null) {
    try {
        // קבלת המשתמש הפעיל אם לא סופק
        // כרגע יש רק משתמש אחד - נימרוד (ID: 1)
        if (!userId) {
            if (typeof window.TikTrackAuth !== 'undefined' && window.TikTrackAuth.getCurrentUser) {
                const currentUser = window.TikTrackAuth.getCurrentUser();
                userId = currentUser ? currentUser.id : 1; // נימרוד - המשתמש היחיד
            } else {
                userId = 1; // נימרוד - המשתמש היחיד במערכת
            }
        }
        
        console.log(`🔍 Getting preference: ${preferenceName} for user: ${userId}`);
        
        // בדיקת מטמון
        const cached = await window.preferencesCache.get();
        if (cached && cached[preferenceName] !== undefined) {
            console.log(`✅ Cache hit for ${preferenceName}:`, cached[preferenceName]);
            return cached[preferenceName];
        }
        
        // שאילתה לשרת
        let url = `/api/preferences/user/single?preference_name=${preferenceName}&user_id=${userId}`;
        if (profileId) {
            url += `&profile_id=${profileId}`;
        }
        
        const response = await fetch(url);
        if (response.ok) {
            const result = await response.json();
            const value = result.data?.value;
            
            console.log(`✅ Retrieved ${preferenceName}:`, value);
            
            // עדכון מטמון רק אם זמין
            if (cached && window.preferencesCache) {
                cached[preferenceName] = value;
                try {
                    await window.preferencesCache.set(cached);
                } catch (cacheError) {
                    console.warn('⚠️ Could not update preferences cache:', cacheError.message);
                }
            }
            
            return value;
      } else if (response.status === 500) {
            // No dummy data - show clear message when preference is missing
            console.log(`⚠️ Preference ${preferenceName} not found in database - returning null`);
            return null;
      } else {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
    } catch (error) {
        console.error(`❌ Error getting preference ${preferenceName}:`, error);
        throw error;
    }
};

/**
 * קבלת קבוצת העדפות
 * @param {string} groupName - שם הקבוצה
 * @param {number} userId - מזהה משתמש (ברירת מחדל: 1)
 * @param {number} profileId - מזהה פרופיל (אופציונלי)
 * @returns {Promise<Object>} - מילון עם העדפות הקבוצה
 */
window.getGroupPreferences = async function(groupName, userId = 1, profileId = null) {
    try {
        console.log(`🔍 Getting group preferences: ${groupName}`);
        
        // בדיקת מטמון
        const cached = await window.preferencesCache.get();
        if (cached && cached[`group_${groupName}`]) {
            console.log(`✅ Cache hit for group ${groupName}`);
            return cached[`group_${groupName}`];
        }
        
        // שאילתה לשרת
        let url = `/api/preferences/user/group?group=${groupName}&user_id=${userId}`;
        if (profileId) {
            url += `&profile_id=${profileId}`;
        }
        
        const response = await fetch(url);
        if (response.ok) {
            const result = await response.json();
            const preferences = result.data?.preferences || {};
            
            console.log(`✅ Retrieved group ${groupName}:`, preferences);
            
            // עדכון מטמון
            if (cached) {
                cached[`group_${groupName}`] = preferences;
                await window.preferencesCache.set(cached);
            }
            
            return {
                success: true,
                data: {
                    preferences: preferences
                }
            };
      } else {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
    } catch (error) {
        console.error(`❌ Error getting group preferences ${groupName}:`, error);
        throw error;
    }
};

/**
 * קבלת העדפות מרובות לפי שמות
 * @param {Array<string>} preferenceNames - רשימת שמות העדפות
 * @param {number} userId - מזהה משתמש (ברירת מחדל: 1)
 * @param {number} profileId - מזהה פרופיל (אופציונלי)
 * @returns {Promise<Object>} - מילון עם העדפות
 */
window.getPreferencesByNames = async function(preferenceNames, userId = null, profileId = null) {
    try {
        // קבלת המשתמש הפעיל אם לא סופק
        // כרגע יש רק משתמש אחד - נימרוד (ID: 1)
        if (!userId) {
            if (typeof window.TikTrackAuth !== 'undefined' && window.TikTrackAuth.getCurrentUser) {
                const currentUser = window.TikTrackAuth.getCurrentUser();
                userId = currentUser ? currentUser.id : 1; // נימרוד - המשתמש היחיד
            } else {
                userId = 1; // נימרוד - המשתמש היחיד במערכת
            }
        }
        
        console.log(`🔍 Getting multiple preferences:`, preferenceNames, `for user: ${userId}`);
        
        // בדיקת מטמון
        const cached = await window.preferencesCache.get();
        const missingFromCache = preferenceNames.filter(name => !cached || cached[name] === undefined);
        
        if (missingFromCache.length === 0 && cached) {
            console.log(`✅ All preferences found in cache`);
            return preferenceNames.reduce((result, name) => {
                result[name] = cached[name];
                return result;
            }, {});
        }
        
        // שאילתה לשרת
        const response = await fetch('/api/preferences/user/multiple', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
            body: JSON.stringify({
                preference_names: preferenceNames,
                user_id: userId,
                profile_id: profileId
            })
        });
        
        if (response.ok) {
            const result = await response.json();
            const preferences = result.data?.preferences || {};
            
            console.log(`✅ Retrieved multiple preferences:`, preferences);
            
            // עדכון מטמון
            if (cached) {
                Object.assign(cached, preferences);
                await window.preferencesCache.set(cached);
            }
            
            return preferences;
          } else {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
    } catch (error) {
        console.error(`❌ Error getting multiple preferences:`, error);
        throw error;
    }
};

/**
 * קבלת כל ההעדפות של משתמש
 * @param {number} userId - מזהה משתמש (ברירת מחדל: 1)
 * @param {number} profileId - מזהה פרופיל (אופציונלי)
 * @returns {Promise<Object>} - מילון עם כל ההעדפות
 */
window.getAllUserPreferences = async function(userId = 1, profileId = null, forceRefresh = false) {
    try {
        console.log(`🔍 Getting all user preferences for user ${userId}, profile: ${profileId || 'active'}, forceRefresh: ${forceRefresh}`);
        
        // בדיקת מטמון - רק אם לא ביקשנו טעינה מחדש
        if (!forceRefresh) {
            const cached = await window.preferencesCache.get();
            if (cached && Object.keys(cached).length > 0) {
                console.log(`✅ All preferences found in cache: ${Object.keys(cached).length} items`);
                // בדיקה אם המטמון מכיל מספיק העדפות (צריך להיות לפחות 50)
                if (Object.keys(cached).length < 50) {
                    console.log(`⚠️ Cache has only ${Object.keys(cached).length} preferences, fetching from server...`);
                } else {
                    return cached;
                }
            }
        } else {
            console.log(`🔄 Force refresh requested, skipping cache check`);
        }
        
        console.log(`🔄 Cache is empty or insufficient, fetching fresh data from server...`);
        
        // ניקוי מטמון מקומי אם הוא לא מספיק
        if (!forceRefresh) {
            await window.preferencesCache.clear();
            console.log(`🧹 Cleared insufficient cache`);
        }
        
        // שאילתה לשרת
        let url = `/api/preferences/user?user_id=${userId}`;
        if (profileId) {
            url += `&profile_id=${profileId}`;
        }
        
        console.log(`🔍 Fetching from URL: ${url}`);
        
        const response = await fetch(url);
        if (response.ok) {
            const result = await response.json();
            const preferences = result.data?.preferences || {};
            const serverProfileId = result.data?.profile_id;
            
            console.log(`✅ Retrieved all preferences:`, preferences);
            console.log(`📂 Server returned profile_id: ${serverProfileId}`);

            // עדכון מטמון
            await window.preferencesCache.set(preferences);
            
            // אם השרת החזיר profile_id, נשתמש בו
            if (serverProfileId && !profileId) {
                console.log(`📂 Using server profile_id: ${serverProfileId}`);
                profileId = serverProfileId;
                
                // עדכון ה-dropdown עם הפרופיל שהשרת החזיר
                const profiles = await window.getUserProfiles(userId);
                const serverProfile = profiles.find(p => p.id === serverProfileId);
                if (serverProfile) {
                    const profileSelect = document.getElementById('profileSelect');
                    if (profileSelect) {
                        profileSelect.value = serverProfile.name;
                        console.log(`📋 Updated dropdown to server profile: ${serverProfile.name}`);
                    }
                    
                    // עדכון activeProfileInfo
                    const activeProfileInfo = document.getElementById('activeProfileInfo');
                    if (activeProfileInfo) {
                        activeProfileInfo.textContent = serverProfile.name;
                        console.log(`📊 Updated active profile info to: ${serverProfile.name}`);
                    }
                }
            }

            // עדכון CSS Variables מצבעים דינמיים
            if (window.colorSchemeSystem && window.colorSchemeSystem.updateCSSVariablesFromPreferences) {
                console.log('🎨 Updating CSS variables from preferences...');
                window.colorSchemeSystem.updateCSSVariablesFromPreferences(preferences);
            }

            return preferences;
        } else {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
    } catch (error) {
        console.error(`❌ Error getting all user preferences:`, error);
        throw error;
    }
};

// ===== SAVE FUNCTIONS =====

/**
 * שמירת העדפה בודדת
 * @param {string} preferenceName - שם ההעדפה
 * @param {any} value - ערך ההעדפה
 * @param {number} userId - מזהה משתמש (ברירת מחדל: 1)
 * @param {number} profileId - מזהה פרופיל (אופציונלי)
 * @returns {Promise<boolean>} - האם השמירה הצליחה
 */
window.savePreference = async function(preferenceName, value, userId = 1, profileId = null) {
    try {
        console.log(`💾 Saving preference: ${preferenceName} = ${value}`);
        
        const response = await fetch('/api/preferences/user/single', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                preference_name: preferenceName,
                value: value,
                user_id: userId,
                profile_id: profileId
            })
        });
        
        if (response.ok) {
            console.log(`✅ Saved preference: ${preferenceName}`);
            
            // עדכון מטמון
            const cached = await window.preferencesCache.get() || {};
            cached[preferenceName] = value;
            await window.preferencesCache.set(cached);
            
            return true;
      } else {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
    } catch (error) {
        console.error(`❌ Error saving preference ${preferenceName}:`, error);
        throw error;
    }
};

/**
 * שמירת העדפות מרובות
 * @param {Object} preferences - מילון עם העדפות
 * @param {number} userId - מזהה משתמש (ברירת מחדל: 1)
 * @param {number} profileId - מזהה פרופיל (אופציונלי)
 * @returns {Promise<boolean>} - האם השמירה הצליחה
 */
window.savePreferences = async function(preferences, userId = 1, profileId = null) {
    try {
        console.log(`💾 Saving multiple preferences:`, preferences);
      
      const response = await fetch('/api/preferences/user', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
            body: JSON.stringify({
                preferences: preferences,
                user_id: userId,
                profile_id: profileId
            })
        });
        
        if (response.ok) {
            const result = await response.json();
            
            if (result.success || result.data) {
                console.log(`✅ Saved multiple preferences:`, result);
                
                // עדכון מטמון - נקה מטמון כדי לטעון מחדש מהשרת
                window.preferencesCache.clear();
                
                return true;
      } else {
                throw new Error(`API returned success: false - ${result.message || 'Unknown error'}`);
            }
      } else {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
    } catch (error) {
        console.error(`❌ Error saving multiple preferences:`, error);
        throw error;
    }
};

// ===== PROFILE MANAGEMENT =====

/**
 * קבלת פרופילים של משתמש
 * @param {number} userId - מזהה משתמש (ברירת מחדל: 1)
 * @returns {Promise<Array>} - רשימת פרופילים
 */
window.getUserProfiles = async function(userId = 1) {
    try {
        console.log(`🔍 Getting user profiles for user ${userId}`);
        
        const response = await fetch(`/api/preferences/profiles?user_id=${userId}`);
        if (response.ok) {
            const result = await response.json();
            const profiles = result.data?.profiles || [];
            
            console.log(`✅ Retrieved user profiles:`, profiles);
            return profiles;
        } else {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
    } catch (error) {
        console.error(`❌ Error getting user profiles:`, error);
        throw error;
    }
};

// ===== UTILITY FUNCTIONS =====

/**
 * מחיקת מטמון העדפות
 */
window.clearPreferencesCache = function() {
    console.log(`🗑️ Clearing preferences cache`);
    window.preferencesCache.clear();
};

/**
 * בדיקת תקינות השירות
 * @returns {Promise<boolean>} - האם השירות תקין
 */
window.checkPreferencesServiceHealth = async function() {
    try {
        console.log(`🔍 Checking preferences service health`);
        
        const base = location.protocol === 'file:' ? 'http://127.0.0.1:8080' : '';
        const response = await fetch(`${base}/api/preferences/health`);
        if (response.ok) {
            const result = await response.json();
            console.log(`✅ Preferences service is healthy:`, result.data);
            return true;
      } else {
            console.log(`❌ Preferences service is unhealthy: HTTP ${response.status}`);
        return false;
      }
    } catch (error) {
        console.error(`❌ Error checking preferences service health:`, error);
      return false;
    }
};

/**
 * קבלת מידע על העדפה
 * @param {string} preferenceName - שם ההעדפה
 * @returns {Promise<Object>} - מידע על ההעדפה
 */
window.getPreferenceInfo = async function(preferenceName) {
    try {
        console.log(`🔍 Getting preference info: ${preferenceName}`);
        
        const response = await fetch(`/api/preferences/info/${preferenceName}`);
        if (response.ok) {
            const result = await response.json();
            const info = result.data?.info;
            
            console.log(`✅ Retrieved preference info:`, info);
            return info;
      } else {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
    } catch (error) {
        console.error(`❌ Error getting preference info:`, error);
        throw error;
    }
};

// ===== LEGACY COMPATIBILITY =====

/**
 * טעינת העדפות (תואם למערכת הישנה)
 * @returns {Promise<boolean>} - האם הטעינה הצליחה
 */
window.loadPreferences = async function(userId = 1, profileId = null) {
    try {
        console.log(`📂 Loading preferences from system... (user: ${userId}, profile: ${profileId})`);
        
        // המתן לאתחול UnifiedCacheManager אם הוא עדיין לא אותחל
        if (window.UnifiedCacheManager && !window.UnifiedCacheManager.initialized) {
            console.log('⏳ Waiting for UnifiedCacheManager initialization...');
            let attempts = 0;
            const maxAttempts = 50; // 5 שניות מקסימום
            
            while (!window.UnifiedCacheManager.initialized && attempts < maxAttempts) {
                await new Promise(resolve => setTimeout(resolve, 100));
                attempts++;
            }
            
            if (!window.UnifiedCacheManager.initialized) {
                console.warn('⚠️ UnifiedCacheManager initialization timeout, proceeding with fallback');
            } else {
                console.log('✅ UnifiedCacheManager initialized, proceeding with preferences loading');
            }
        }
        
        // Clear cache to ensure fresh data
        if (window.preferencesCache && window.preferencesCache.clear) {
            console.log('🗑️ Clearing preferences cache before loading...');
            window.preferencesCache.clear();
        }
        
        // אם לא צוין profileId, נטען את הפרופיל הפעיל
        if (!profileId) {
            const profiles = await window.getUserProfiles(userId);
            const activeProfile = profiles.find(p => p.active);
            if (activeProfile) {
                profileId = activeProfile.id;
                console.log(`📂 Using active profile: ${activeProfile.name} (ID: ${profileId})`);
                
                // Update dropdown to show the active profile
                const profileSelect = document.getElementById('profileSelect');
                if (profileSelect) {
                    profileSelect.value = activeProfile.name;
                    console.log(`📋 Set dropdown to active profile: ${activeProfile.name}`);
                }
            }
        }
        
        const preferences = await window.getAllUserPreferences(userId, profileId);
        
        // Apply preferences to form - update all fields
        console.log('🎯 Applying preferences to form...');
        
        // Update all form fields
        Object.keys(preferences).forEach(key => {
            const element = document.getElementById(key);
            if (element) {
                const value = preferences[key];
                
                if (element.type === 'checkbox') {
                    // Handle boolean values that might come as strings
                    const boolValue = (value === true || value === 'true' || value === '1' || value === 1);
                    element.checked = boolValue;
                } else if (element.type === 'number') {
                    element.value = parseFloat(value) || 0;
                } else if (element.type === 'color') {
                    element.value = value || '#000000';
                } else if (element.tagName === 'SELECT') {
                    element.value = value || '';
                } else {
                    element.value = value || '';
                }
                
                console.log(`🎯 Updated ${key} = ${value} (type: ${element.type || element.tagName})`);
            }
        });
        
        console.log('✅ All form fields updated successfully');
        
        // Set global preferences for easy access
        window.currentPreferences = preferences;
        
        // Return preferences data
        return {
            success: true,
            data: preferences
        };
    } catch (error) {
        console.error('❌ Error loading preferences:', error);
        
        // Show error notification
        if (typeof window.showError === 'function') {
            window.showError('שגיאה בטעינת העדפות', 'שגיאה בטעינת העדפות מהמערכת החדשה: ' + error.message);
        }
        
        return {
            success: false,
            error: error.message
        };
    }
};


/**
 * טעינת כל ההעדפות לעמוד
 * @returns {Promise<boolean>} - האם הטעינה הצליחה
 */
window.loadAllPreferences = async function() {
    try {
        console.log('📥 Loading all preferences to page...');
        
        // Load preferences from server
        const preferences = await window.getAllUserPreferences();
        
        if (preferences) {
            // Populate form fields with loaded preferences
            await window.populatePreferencesForm(preferences);
            
            // Update UI counters
            window.updatePreferencesCounters(preferences);
            
            // Load profiles to dropdown to ensure sync
            await window.loadProfilesToDropdown();
            
            // Load active accounts to dropdown - REMOVED: now handled by loadAccountsForPreferences()
            // Reason: loadAccountsForPreferences() uses SelectPopulatorService and handles preferences correctly
            // The old loadActiveAccountsToDropdown() was clearing the dropdown after it was already populated
            
            // Load default colors if no color preferences exist
            if (window.loadDefaultColors) {
                window.loadDefaultColors();
            }
            
            // אתחול מעקב שינויים אחרי טעינת כל ההעדפות
            setTimeout(() => {
                if (window.initializeChangeTracking) {
                    window.initializeChangeTracking();
                }
            }, 200);
            
            console.log('✅ All preferences loaded successfully');
            return true;
        } else {
            console.warn('⚠️ No preferences loaded');
            return false;
        }
    } catch (error) {
        console.error('❌ Error loading preferences:', error);
        return false;
    }
};


// ===== INITIALIZATION =====

/**
 * אתחול מערכת העדפות
 */
window.initializePreferences = async function() {
    try {
        console.log('🚀 Initializing Preferences System...');
        
        // בדיקת תקינות השירות
        const isHealthy = await window.checkPreferencesServiceHealth();
        if (!isHealthy) {
            console.warn('⚠️ Preferences service is not healthy, using fallback');
        return false;
      }
      
        // טעינת העדפות ראשונית
        await window.loadAllPreferences();
      
        console.log('✅ Preferences System initialized successfully');
      return true;
    } catch (error) {
        console.error('❌ Error initializing Preferences System:', error);
      return false;
    }
};

// ===== RESET TO DEFAULTS =====

/**
 * איפוס כל ההעדפות לברירות מחדל
 * Reset all preferences to default values
 * 
 * @returns {Promise<boolean>} - האם האיפוס הצליח
 */
window.resetToDefaults = async function() {
    try {
        console.log('🔄 Resetting all preferences to defaults...');
        
        // קבלת כל ההעדפות הנוכחיות
        const currentPreferences = await window.getAllUserPreferences();
        if (!currentPreferences.success) {
            throw new Error('Failed to get current preferences');
        }
        
        // קבלת ברירות מחדל מהמערכת
        const response = await fetch('/api/preferences/admin/types');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        const preferenceTypes = data.data.preference_types || [];
        
        // יצירת אובייקט עם ברירות מחדל
        const defaultPreferences = {};
        preferenceTypes.forEach(pref => {
            if (pref.default_value !== null) {
                defaultPreferences[pref.preference_name] = pref.default_value;
            }
        });
        
        // שמירת ברירות המחדל
        const saveResult = await window.savePreferences(defaultPreferences);
        if (saveResult) {
            console.log('✅ All preferences reset to defaults successfully');
            
            // Show success notification before page reload
            if (typeof window.showSuccessNotification === 'function') {
                window.showSuccessNotification('העדפות אופסו לברירות מחדל!', 'הדף ירענן בעוד רגע');
            } else if (typeof window.showNotification === 'function') {
                window.showNotification('העדפות אופסו לברירות מחדל!', 'success');
            }
            
            // רענון הדף
            setTimeout(() => {
                window.location.reload();
            }, 2000); // Increased delay to show notification
            
            return true;
    } else {
            throw new Error('Failed to save default preferences');
    }
    
  } catch (error) {
        console.error('❌ Error resetting preferences to defaults:', error);
        
        if (typeof showNotification === 'function') {
            showNotification('שגיאה באיפוס ההעדפות: ' + error.message, 'error');
        } else {
            alert('שגיאה באיפוס ההעדפות: ' + error.message);
        }
        
        return false;
    }
};

// ===== PROFILE MANAGEMENT =====

/**
 * טעינת פרופילים לרשימה הנפתחת
 */
window.loadProfilesToDropdown = async function() {
    try {
        console.log('📂 Loading profiles to dropdown...');
        
        const profiles = await window.getUserProfiles();
        const profileSelect = document.getElementById('profileSelect');
        
        if (!profileSelect) {
            console.warn('⚠️ Profile select element not found');
            return false;
        }
        
        // נקה את הרשימה
        profileSelect.innerHTML = '';
        
        if (profiles && profiles.length > 0) {
            profiles.forEach(profile => {
                const option = document.createElement('option');
                option.value = profile.name;
                option.textContent = profile.name;
                if (profile.active) {
                    option.selected = true;
                }
                profileSelect.appendChild(option);
            });
            
            // עדכון ה-dropdown עם הערך הנוכחי אם הוא כבר מוגדר
            const currentValue = profileSelect.value;
            if (currentValue) {
                profileSelect.value = currentValue;
                console.log(`📋 Preserved dropdown value: ${currentValue}`);
            }
            
            console.log(`✅ Loaded ${profiles.length} profiles to dropdown`);
            
            // עדכון הסטטיסטיקה - פרופיל פעיל (רק אם לא עודכן כבר)
            const activeProfile = profiles.find(p => p.active);
            const activeProfileInfo = document.getElementById('activeProfileInfo');
            if (activeProfileInfo && activeProfile && !activeProfileInfo.textContent) {
                activeProfileInfo.textContent = activeProfile.name;
                console.log(`📊 Updated active profile info on initial load: ${activeProfile.name}`);
            }
            
            return true;
        } else {
            // הוסף אפשרות ברירת מחדל
            const defaultOption = document.createElement('option');
            defaultOption.value = 'ברירת מחדל';
            defaultOption.textContent = 'ברירת מחדל';
            defaultOption.selected = true;
            profileSelect.appendChild(defaultOption);
            
            // עדכון הסטטיסטיקה - ברירת מחדל (רק אם לא עודכן כבר)
            const activeProfileInfo = document.getElementById('activeProfileInfo');
            if (activeProfileInfo && !activeProfileInfo.textContent) {
                activeProfileInfo.textContent = 'ברירת מחדל';
                console.log(`📊 Updated active profile info on initial load: ברירת מחדל`);
            }
            
            console.log('✅ Added default profile option');
            return true;
    }
    
  } catch (error) {
        console.error('❌ Error loading profiles to dropdown:', error);
        return false;
    }
};

/**
 * טעינת פרופיל
 */
window.loadProfile = async function() {
    try {
        console.log('📂 Loading profile...');
        
        // Profiles are loaded automatically by loadAllPreferences, no need to load again
        
        // קבלת פרופיל נבחר
        const profileSelect = document.getElementById('profileSelect');
        if (!profileSelect) {
            throw new Error('Profile select element not found');
        }
        
        const selectedProfile = profileSelect.value;
        if (!selectedProfile || selectedProfile === 'ברירת מחדל') {
            // Default profile is loaded automatically by loadAllPreferences
            console.log('✅ Default profile loaded');
    } else {
            // טעינת פרופיל ספציפי
            const profiles = await window.getUserProfiles();
            const profile = profiles.find(p => p.name === selectedProfile);
            
            if (profile) {
                await window.loadPreferences(1, profile.id);
                console.log(`✅ Profile loaded: ${selectedProfile}`);
            } else {
                throw new Error(`Profile not found: ${selectedProfile}`);
            }
        }
        
        // הסטטיסטיקה תתעדכן רק אחרי שמירה אמיתית בבסיס הנתונים
        
        // הצגת הודעת הצלחה
    if (typeof window.showSuccessNotification === 'function') {
            window.showSuccessNotification('פרופיל נטען בהצלחה!');
    }
    
        return true;
        
  } catch (error) {
        console.error('❌ Error loading profile:', error);
    if (typeof window.showErrorNotification === 'function') {
            window.showErrorNotification('שגיאה בטעינת פרופיל: ' + error.message);
        }
        return false;
    }
};

/**
 * החלפת פרופיל פעיל
 */
window.switchProfile = async function(profileId) {
    try {
        console.log(`🔄 Switching to profile: ${profileId}`);
        
        // עדכון פרופיל פעיל בשרת
        const response = await fetch('/api/preferences/profiles/activate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                user_id: 1,
                profile_id: profileId
            })
        });
        
        if (response.ok) {
            const result = await response.json();
            if (result.success || result.data) {
                // נקה מטמון וטען מחדש
                window.preferencesCache.clear();
                // Preferences will be reloaded by the calling function
                
                console.log('✅ Profile switched successfully');
                
                // הסטטיסטיקה תתעדכן רק בפונקציה saveAsActiveProfile
                
      if (typeof window.showSuccessNotification === 'function') {
                    window.showSuccessNotification('פרופיל הוחלף בהצלחה!');
                }
                
                return true;
            }
        }
        
        throw new Error('Failed to switch profile');
        
  } catch (error) {
        console.error('❌ Error switching profile:', error);
    if (typeof window.showErrorNotification === 'function') {
            window.showErrorNotification('שגיאה בהחלפת פרופיל: ' + error.message);
        }
        return false;
    }
};

/**
 * שמירת העדפות נוכחיות כפרופיל פעיל
 * @returns {Promise<boolean>} - האם השמירה הצליחה
 */
window.saveAsActiveProfile = async function() {
    try {
        console.log('💾 Saving current preferences as active profile...');
        
        // Collect form data
        if (typeof window.collectFormData === 'function') {
            console.log('📋 Calling collectFormData...');
            const formData = window.collectFormData();
            
            // Debug: Log form data to see what we're collecting
            console.log('📋 Form data collected:', formData);
            
            if (Object.keys(formData).length === 0) {
                console.warn('⚠️ No form data to save');
                if (typeof window.showWarningNotification === 'function') {
                    window.showWarningNotification('אזהרה', 'אין העדפות לשמירה');
                }
                return false;
            }
            
            // Debug: Check if profileSelect is in form data
            if (formData.profileSelect) {
                console.log('📋 Profile selection in form data:', formData.profileSelect);
            } else {
                console.warn('⚠️ Profile selection not found in form data!');
            }
            
            // Get the selected profile from dropdown (not necessarily the active one)
            console.log('👤 Getting user profiles...');
            const profiles = await window.getUserProfiles();
            console.log('👤 Available profiles:', profiles);
            
            // Debug: Check current dropdown value
            const profileSelect = document.getElementById('profileSelect');
            if (profileSelect) {
                console.log('📋 Current dropdown value:', profileSelect.value);
                console.log('📋 Current dropdown options:', Array.from(profileSelect.options).map(o => o.value));
            }
            
            const selectedProfileName = profileSelect ? profileSelect.value : null;
            console.log('👤 Selected profile from dropdown:', selectedProfileName);
            
            let targetProfile = null;
            if (!selectedProfileName || selectedProfileName === 'ברירת מחדל') {
                targetProfile = profiles.find(p => p.name === 'ברירת מחדל');
            } else {
                targetProfile = profiles.find(p => p.name === selectedProfileName);
            }
            
            if (!targetProfile) {
                throw new Error(`Profile not found: ${selectedProfileName}`);
            }
            
            console.log(`💾 Saving to selected profile: ${targetProfile.name} (ID: ${targetProfile.id})`);
            
            // Debug: Check if target profile is already active
            const currentActiveProfile = profiles.find(p => p.active);
            if (currentActiveProfile && currentActiveProfile.id === targetProfile.id) {
                console.log('⚠️ Target profile is already active, no need to switch');
                if (typeof window.showInfoNotification === 'function') {
                    window.showInfoNotification('מידע', 'הפרופיל כבר פעיל');
                }
                return true;
            }
            
            // Save preferences to selected profile
            if (typeof window.savePreferences === 'function') {
                console.log('💾 Calling savePreferences...');
                const result = await window.savePreferences(formData, 1, targetProfile.id);
                console.log('💾 Save result:', result);
                
                if (result) {
                    console.log('✅ Preferences saved to selected profile successfully');
                    
                    // Step 1: Switch active profile in database
                    console.log(`🔄 Switching active profile in database to: ${targetProfile.name} (ID: ${targetProfile.id})...`);
                    try {
                        await window.switchProfile(targetProfile.id);
                        console.log('✅ Profile switch completed successfully');
                    } catch (error) {
                        console.error('❌ Error switching profile:', error);
                        throw error;
                    }
                    
                    // Step 2: Clear all caches using global cache clearing system
                    console.log('🗑️ Clearing all caches using global system...');
                    if (window.preferencesCache && window.preferencesCache.clear) {
                        window.preferencesCache.clear();
                    }
                    
                    // Clear other system caches if available
                    if (typeof window.clearGlobalCache === 'function') {
                        window.clearGlobalCache('preferences', 'full');
                    }
                    
                    // Clear localStorage and IndexedDB for preferences
                    try {
                        // Clear localStorage items related to preferences (fallback)
                        const keysToRemove = [];
                        for (let i = 0; i < localStorage.length; i++) {
                            const key = localStorage.key(i);
                            if (key && (key.includes('preferences') || key.includes('profile'))) {
                                keysToRemove.push(key);
                            }
                        }
                        keysToRemove.forEach(key => localStorage.removeItem(key));
                        console.log(`🗑️ Cleared ${keysToRemove.length} localStorage items related to preferences (fallback)`);
                        
                        // Clear unified cache system if available
                        if (window.UnifiedCacheManager && window.UnifiedCacheManager.initialized) {
                            try {
                                await window.UnifiedCacheManager.clear('preferences');
                                console.log('🗑️ Cleared unified cache preferences');
                            } catch (error) {
                                console.warn('⚠️ Could not clear unified cache preferences:', error);
                            }
                        }
                    } catch (error) {
                        console.warn('⚠️ Error clearing additional caches:', error);
                    }
                    
                    // Step 3: Reload all data from database according to new active profile
                    console.log('🔄 Reloading all data from database for new active profile...');
                    
                    // Clear preferences cache before loading to ensure fresh data
                    if (window.preferencesCache && window.preferencesCache.clear) {
                        window.preferencesCache.clear();
                        console.log('🗑️ Cleared preferences cache before reload');
                    }
                    
                    await window.loadPreferences();
                    // Colors and profiles are loaded automatically by loadPreferences
                    
                    // Ensure dropdown shows the correct selected profile
                    const profileSelect = document.getElementById('profileSelect');
                    if (profileSelect) {
                        profileSelect.value = targetProfile.name;
                        console.log(`📋 Updated dropdown selection to: ${targetProfile.name}`);
                    }
                    
                    // Step 4: Update statistics
                    const activeProfileInfo = document.getElementById('activeProfileInfo');
                    if (activeProfileInfo) {
                        activeProfileInfo.textContent = targetProfile.name;
                        console.log(`📊 Updated active profile info: ${targetProfile.name}`);
                    }
                    
                    // Show success notification
                    if (typeof window.showSuccessNotification === 'function') {
                        window.showSuccessNotification('הצלחה', `פרופיל "${targetProfile.name}" הופעל והעדפות נשמרו בהצלחה`);
                    }
                    
                    return true;
                }
            } else {
                console.error('❌ window.savePreferences function not available');
            }
        } else {
            console.error('❌ window.collectFormData function not available');
        }
        
        throw new Error('Failed to save preferences');
        
    } catch (error) {
        console.error('❌ Error saving preferences to active profile:', error);
        
        // Show error notification
        if (typeof window.showErrorNotification === 'function') {
            window.showErrorNotification('שגיאה', 'שגיאה בשמירת העדפות: ' + error.message);
        }
        
        return false;
    }
};

// ===== AUTO-INITIALIZATION =====

// Note: Preferences initialization is handled by Unified App Initializer
// in page-initialization-configs.js to avoid duplication

// ===== USER PROFILES =====


// ===== COPY DETAILED LOG =====

/**
 * העתקת לוג מפורט של עמוד ההעדפות - מה המשתמש רואה
 * מבוסס על המדריך: DETAILED_LOG_SYSTEM_GUIDE.md
 */
async function copyDetailedLog() {
    try {
        console.log('🚀🚀🚀 PREFERENCES copyDetailedLog function called!');
        console.log('📋 Generating detailed log for preferences page...');
        console.log('🎯 This should be the PREFERENCES log, not system management!');
        
        const log = [];
        const timestamp = new Date().toLocaleString('he-IL');
        
        // Header - לפי המדריך
        log.push('=== לוג מפורט - עמוד העדפות TikTrack ===');
        console.log('🎯 PREFERENCES LOG: Starting to build log...');
        log.push(`זמן יצירה: ${timestamp}`);
        log.push(`עמוד: ${window.location.href}`);
        log.push('');
        
        // 1. מצב כללי של העמוד - לפי המדריך
        log.push('--- מצב כללי של העמוד ---');
        log.push(`כותרת: ${document.title}`);
        log.push(`סטטוס טעינה: ${document.readyState}`);
        
        // Page Title Info
        const pageHeader = document.querySelector('.page-header h1');
        if (pageHeader) {
            log.push(`כותרת עמוד: ${pageHeader.textContent.trim()}`);
        }
        
        // Header Info - שיפור שלי
        const header = document.getElementById('unified-header');
        if (header) {
            const navItems = header.querySelectorAll('.tiktrack-nav-item');
            log.push(`פריטי ניווט: ${navItems.length}`);
            
            // בדיקת נראות - לפי המדריך
            const visibleNavItems = Array.from(navItems).filter(item => 
                item && item.offsetParent !== null
            ).length;
            log.push(`פריטי ניווט נראים: ${visibleNavItems}`);
        } else {
            log.push('Header: לא נמצא');
        }
        log.push('');
        
        // 2. סטטיסטיקות - מה המשתמש רואה (לפי המדריך)
        log.push('--- סטטיסטיקות ---');
        const stats = [
            { id: 'preferencesCount', label: 'מספר העדפות' },
            { id: 'profilesCount', label: 'מספר פרופילים' },
            { id: 'groupsCount', label: 'מספר קבוצות' }
        ];
        
        stats.forEach(stat => {
            const element = document.getElementById(stat.id);
            const value = element ? element.textContent.trim() : '0';
            const visible = element && element.offsetParent !== null ? 'נראה' : 'לא נראה';
            log.push(`${stat.label}: ${value} (${visible})`);
        });
        
        // פרופיל פעיל - שיפור שלי
        const activeProfileElement = document.getElementById('activeProfileInfo');
        if (activeProfileElement) {
            log.push(`פרופיל נוכחי: ${activeProfileElement.textContent.trim()}`);
        }
        log.push('');
        
        // 3. מצב סקשנים - לפי המדריך עם שיפורים
        log.push('--- מצב סקשנים ---');
        const sections = document.querySelectorAll('.content-section, .top-section');
        log.push(`מספר סקשנים: ${sections.length}`);
        
        sections.forEach((section, index) => {
            const sectionId = section.id || `section-${index + 1}`;
            const sectionBody = section.querySelector('.section-body');
            const isVisible = sectionBody ? 
                sectionBody.style.display !== 'none' && !sectionBody.classList.contains('collapsed') : 
                true;
            const toggleIcon = section.querySelector('.section-toggle-icon');
            const iconText = toggleIcon ? toggleIcon.textContent.trim() : '?';
            const visible = section && section.offsetParent !== null ? 'נראה' : 'לא נראה';
            
            log.push(`  ${index + 1}. "${sectionId}": ${isVisible ? 'פתוח' : 'סגור'} (${iconText}) - ${visible}`);
        });
        log.push('');
        
        // 4. הגדרות/העדפות - לפי המדריך
        log.push('--- הגדרות בסיסיות ---');
        const basicSettings = [
            { id: 'primaryCurrency', label: 'מטבע ראשי' },
            { id: 'secondaryCurrency', label: 'מטבע משני' },
            { id: 'timezone', label: 'אזור זמן' },
            { id: 'language', label: 'שפה' }
        ];
        
        basicSettings.forEach(setting => {
            const element = document.getElementById(setting.id);
            if (element) {
                const value = element.value || element.textContent?.trim() || 'לא מוגדר';
                const visible = element.offsetParent !== null ? 'נראה' : 'לא נראה';
                log.push(`${setting.label}: ${value} (${visible})`);
            }
        });
        log.push('');
        
        // הגדרות מסחר - שיפור שלי
        log.push('--- הגדרות מסחר ---');
        const tradingSettings = [
            { id: 'maxRisk', label: 'סיכון מקסימלי' },
            { id: 'maxAccountRisk', label: 'סיכון חשבון מקסימלי' },
            { id: 'maxPositionSize', label: 'גודל פוזיציה מקסימלי' },
            { id: 'maxTradeRisk', label: 'סיכון עסקה מקסימלי' }
        ];
        
        tradingSettings.forEach(setting => {
            const element = document.getElementById(setting.id);
            if (element) {
                const value = element.value || element.textContent?.trim() || 'לא מוגדר';
                log.push(`${setting.label}: ${value}`);
            }
        });
        log.push('');
        
        // 5. Checkboxes - לפי המדריך (ללא הגבלה)
        log.push('--- הגדרות פעילות ---');
        const checkboxes = document.querySelectorAll('input[type="checkbox"]');
        log.push(`מספר checkboxes: ${checkboxes.length}`);
        
        checkboxes.forEach((checkbox, index) => {
            const label = checkbox.closest('label')?.textContent?.trim() || 
                         checkbox.getAttribute('name') || 
                         `checkbox-${index + 1}`;
            const status = checkbox.checked ? 'מופעל' : 'מבוטל';
            const visible = checkbox.offsetParent !== null ? 'נראה' : 'לא נראה';
            log.push(`  ${index + 1}. ${label}: ${status} (${visible})`);
        });
        log.push('');
        
        // 6. כפתורים - לפי המדריך
        log.push('--- כפתורים ---');
        const buttonIds = ['saveAllBtn', 'resetBtn', 'toggleAllBtn'];
        buttonIds.forEach(btnId => {
            const btn = document.getElementById(btnId);
            if (btn) {
                const visible = btn.offsetParent !== null ? 'נראה' : 'לא נראה';
                const disabled = btn.disabled ? 'מבוטל' : 'פעיל';
                const text = btn.textContent?.trim() || btn.value || 'ללא טקסט';
                log.push(`${btnId}: ${visible} - ${disabled} - "${text}"`);
            } else {
                log.push(`${btnId}: לא קיים`);
            }
        });
        log.push('');
        
        // בחירת פרופיל - שיפור שלי
        const profileSelect = document.getElementById('profileSelect');
        if (profileSelect) {
            log.push('--- בחירת פרופיל ---');
            log.push(`פרופיל נבחר: ${profileSelect.value}`);
            const options = Array.from(profileSelect.options).map(opt => opt.text);
            log.push(`אפשרויות זמינות: ${options.join(', ')}`);
            log.push('');
        }
        
        // 6.5. צבעים - שיפור שלי
        log.push('--- צבעים ---');
        const colorFields = [
            'primaryColor', 'secondaryColor', 'successColor', 'warningColor', 'dangerColor', 'infoColor',
            'entityTradePlanColor', 'entityTradePlanColorLight', 'entityTradePlanColorDark',
            'entityTradeColor', 'entityTradeColorLight', 'entityTradeColorDark',
            'entityAlertColor', 'entityAlertColorLight', 'entityAlertColorDark',
            'entityNoteColor', 'entityNoteColorLight', 'entityNoteColorDark',
            'entityTradingAccountColor', 'entityTradingAccountColorLight', 'entityTradingAccountColorDark',
            'entityTickerColor', 'entityTickerColorLight', 'entityTickerColorDark',
            'entityExecutionColor', 'entityExecutionColorLight', 'entityExecutionColorDark',
            'entityCashFlowColor', 'entityCashFlowColorLight', 'entityCashFlowColorDark',
            'valuePositiveColor', 'valuePositiveColorLight', 'valuePositiveColorDark',
            'valueNegativeColor', 'valueNegativeColorLight', 'valueNegativeColorDark',
            'valueNeutralColor', 'valueNeutralColorLight', 'valueNeutralColorDark',
            'chartPrimaryColor', 'chartBackgroundColor', 'chartTextColor', 'chartGridColor', 'chartBorderColor', 'chartPointColor'
        ];
        
        let colorsFound = 0;
        colorFields.forEach(fieldName => {
            const colorInput = document.getElementById(fieldName);
            if (colorInput && colorInput.value) {
                log.push(`${fieldName}: ${colorInput.value}`);
                colorsFound++;
            }
        });
        
        if (colorsFound === 0) {
            log.push('⚠️ אין צבעים מוגדרים - כל השדות ריקים!');
            log.push('🔧 צריך לטעון צבעי ברירת מחדל');
        } else {
            log.push(`✅ סה"כ צבעים מוגדרים: ${colorsFound}/${colorFields.length}`);
        }
        
        // 7. סטטוס חיבור/מערכת - לפי המדריך
        log.push('--- סטטוס מערכת ---');
        try {
            const healthResponse = await fetch('/api/preferences/health');
            if (healthResponse.ok) {
                const healthData = await healthResponse.json();
                log.push(`API מערכת העדפות: ${healthData.success ? 'עובד' : 'לא עובד'}`);
                if (healthData.data) {
                    log.push(`סטטוס: ${healthData.data.status}`);
                }
            }
        } catch (error) {
            log.push(`API מערכת העדפות: שגיאה - ${error.message}`);
        }
        
        // Cache Status - שיפור שלי
        if (window.preferencesCache) {
            log.push(`Cache תקין: ${window.preferencesCache.isValid() ? 'כן' : 'לא'}`);
            log.push(`Cache size: ${Object.keys(window.preferencesCache.data || {}).length} פריטים`);
        }
        log.push('');
        
        // 8. מידע טכני - לפי המדריך
        log.push('--- מידע טכני ---');
        log.push(`זמן יצירת הלוג: ${timestamp}`);
        log.push(`גרסת דפדפן: ${navigator.userAgent}`);
        log.push(`רזולוציה מסך: ${screen.width}x${screen.height}`);
        log.push(`גודל חלון: ${window.innerWidth}x${window.innerHeight}`);
        log.push(`שפת דפדפן: ${navigator.language}`);
        log.push(`פלטפורמה: ${navigator.platform}`);
        
        // שיפורים שלי - מידע נוסף
        log.push(`זמן טעינת עמוד: ${performance.timing ? 
            (performance.timing.loadEventEnd - performance.timing.navigationStart) + 'ms' : 
            'לא זמין'}`);
        log.push(`זיכרון זמין: ${navigator.deviceMemory ? navigator.deviceMemory + 'GB' : 'לא זמין'}`);
        log.push('');
        
        // Footer - לפי המדריך
        log.push('=== סוף לוג ===');
        
        const logText = log.join('\n');
        
        // Copy to clipboard with fallback for focus issues
        try {
            await navigator.clipboard.writeText(logText);
        } catch (clipboardError) {
            // Fallback: create a temporary textarea for copying
            console.log('📋 Clipboard API failed, using fallback method...');
            const textarea = document.createElement('textarea');
            textarea.value = logText;
            textarea.style.position = 'fixed';
            textarea.style.opacity = '0';
            document.body.appendChild(textarea);
            textarea.select();
            textarea.setSelectionRange(0, 99999); // For mobile devices
            document.execCommand('copy');
            document.body.removeChild(textarea);
        }
        
        // Show success notification ONLY after successful copy
        if (typeof window.showSuccessNotification === 'function') {
            window.showSuccessNotification('לוג מפורט הועתק ללוח', 'הלוג מכיל את כל מה שרואה המשתמש בעמוד');
        } else if (typeof window.showNotification === 'function') {
            window.showNotification('לוג מפורט הועתק ללוח', 'success');
        } else {
            alert('לוג מפורט הועתק ללוח!');
        }
        
        console.log('📋 Detailed log copied to clipboard');
        console.log('📋 Log content:', logText);
        
        return true;
        
    } catch (error) {
        console.error('❌ Error copying detailed log:', error);
        
        if (typeof window.showErrorNotification === 'function') {
            window.showErrorNotification('שגיאה בהעתקת הלוג', error.message);
        } else if (typeof window.showNotification === 'function') {
            window.showNotification('שגיאה בהעתקת הלוג: ' + error.message, 'error');
        } else {
            alert('שגיאה בהעתקת הלוג: ' + error.message);
        }
        
        return false;
    }
};

/**
 * העתקת לוג מפורט של מערכת העדפות
 */
window.copyPreferencesDetailedLog = async function() {
    try {
        const timestamp = new Date().toLocaleString('he-IL');
        
        // קבלת מידע על המשתמש הפעיל
        let activeProfile = 'לא זמין';
        if (typeof window.TikTrackAuth !== 'undefined' && window.TikTrackAuth.getCurrentUser) {
            const currentUser = window.TikTrackAuth.getCurrentUser();
            if (currentUser) {
                activeProfile = currentUser.name || currentUser.username || 'נימרוד';
            }
        }
        
        // קבלת מספר העדפות
        let preferencesCount = 'לא זמין';
        try {
            const cached = await window.preferencesCache.get();
            if (cached) {
                preferencesCount = Object.keys(cached).length;
            }
        } catch (error) {
            console.warn('Error getting preferences count:', error);
        }
        
        // קבלת מספר פרופילים
        let profilesCount = 1; // נימרוד - המשתמש היחיד
        try {
            if (typeof window.getUserProfiles === 'function') {
                const profiles = await window.getUserProfiles();
                profilesCount = profiles ? profiles.length : 1;
            }
        } catch (error) {
            console.warn('Error getting profiles count:', error);
            profilesCount = 1; // נימרוד - המשתמש היחיד
        }
        
        // איסוף מידע על כל הסקשנים
        const sections = [];
        for (let i = 1; i <= 7; i++) {
            const section = document.getElementById(`section${i}`);
            if (section) {
                const title = section.querySelector('h2')?.textContent || `סקשן ${i}`;
                const isVisible = !section.classList.contains('d-none');
                sections.push(`  ${i}. ${title}: ${isVisible ? 'פתוח' : 'סגור'}`);
            }
        }
        
        // איסוף מידע על העדפות פעילות
        const activePreferences = [];
        const preferenceInputs = document.querySelectorAll('input[type="checkbox"], input[type="range"], select');
        preferenceInputs.forEach(input => {
            if (input.type === 'checkbox') {
                activePreferences.push(`  ${input.name || input.id}: ${input.checked ? 'פעיל' : 'לא פעיל'}`);
            } else if (input.type === 'range') {
                activePreferences.push(`  ${input.name || input.id}: ${input.value}`);
            } else if (input.tagName === 'SELECT') {
                activePreferences.push(`  ${input.name || input.id}: ${input.value}`);
            }
        });
        
        const logContent = `🔔 לוג מפורט - מערכת העדפות
📅 תאריך ושעה: ${timestamp}
👤 פרופיל פעיל: ${activeProfile}
📊 מספר העדפות: ${preferencesCount}
👥 מספר פרופילים: ${profilesCount}

📋 סטטוס סקשנים:
${sections.join('\n')}

⚙️ העדפות פעילות:
${activePreferences.slice(0, 20).join('\n')}${activePreferences.length > 20 ? '\n  ... ועוד ' + (activePreferences.length - 20) + ' העדפות' : ''}

🔧 מידע טכני:
  - מערכת העדפות: פעילה
  - Cache: ${window.preferencesCache.isValid() ? 'תקין' : 'לא תקין'}
  - שירות: ${typeof window.preferencesService !== 'undefined' ? 'זמין' : 'זמין (מקומי)'}

📝 הערות:
  - לוג זה מכיל מידע על מצב מערכת העדפות
  - כולל פרופיל פעיל, העדפות, וסטטוס סקשנים
  - נוצר אוטומטית על ידי מערכת העדפות`;

        navigator.clipboard.writeText(logContent).then(() => {
            if (window.showSuccessNotification) {
                window.showSuccessNotification('לוג מפורט הועתק ללוח');
            } else {
                alert('לוג מפורט הועתק ללוח');
            }
        }).catch(err => {
            console.error('שגיאה בהעתקה:', err);
            if (window.showErrorNotification) {
                window.showErrorNotification('שגיאה בהעתקת הלוג');
            } else {
                alert('שגיאה בהעתקת הלוג');
            }
        });
        
    } catch (error) {
        console.error('שגיאה ביצירת לוג מפורט:', error);
        if (window.showErrorNotification) {
            window.showErrorNotification('שגיאה ביצירת הלוג');
        } else {
            alert('שגיאה ביצירת הלוג');
        }
    }
};

/**
 * מילוי טפסי ההעדפות עם נתונים
 * @param {Object} preferences - נתוני ההעדפות
 */
window.populatePreferencesForm = async function(preferences) {
    try {
        console.log('📝 Populating preferences form...');
        console.log('📝 Preferences received:', Object.keys(preferences).length, 'items');
        
        // Basic settings
        if (preferences.primaryCurrency) {
            const currencySelect = document.getElementById('primaryCurrency');
            if (currencySelect) currencySelect.value = preferences.primaryCurrency;
        }
        
        if (preferences.timezone) {
            const timezoneSelect = document.getElementById('timezone');
            if (timezoneSelect) timezoneSelect.value = preferences.timezone;
        }
        
        // Notification settings
        const notificationSettings = [
            'enableNotifications', 'notificationPopup', 'notificationSound',
            'notifyOnTradeExecuted', 'notifyOnStopLoss'
        ];
        
        notificationSettings.forEach(setting => {
            const element = document.getElementById(setting);
            if (element && preferences[setting] !== undefined) {
                element.checked = preferences[setting];
            }
        });
        
        // Notification categories
        const categorySettings = [
            'notifications_development_enabled', 'notifications_system_enabled',
            'notifications_business_enabled', 'notifications_performance_enabled',
            'notifications_ui_enabled', 'notifications_general_enabled'
        ];
        
        categorySettings.forEach(setting => {
            const element = document.getElementById(setting);
            if (element && preferences[setting] !== undefined) {
                element.checked = preferences[setting];
            }
        });
        
        // Console logs
        const consoleSettings = [
            'console_logs_development_enabled', 'console_logs_system_enabled',
            'console_logs_business_enabled', 'console_logs_performance_enabled',
            'console_logs_ui_enabled'
        ];
        
        consoleSettings.forEach(setting => {
            const element = document.getElementById(setting);
            if (element && preferences[setting] !== undefined) {
                element.checked = preferences[setting];
            }
        });
        
        // Trading settings - עם ערכי ברירת מחדל
        const defaultStopLoss = preferences.defaultStopLoss || '2.0';
        const defaultTargetPrice = preferences.defaultTargetPrice || '4.0';
        const defaultCommission = preferences.defaultCommission || '0.65';
        
        const stopLossElement = document.getElementById('defaultStopLoss');
        if (stopLossElement) {
            stopLossElement.value = defaultStopLoss;
            console.log(`📊 Set defaultStopLoss: ${defaultStopLoss}`);
        }
        
        const targetPriceElement = document.getElementById('defaultTargetPrice');
        if (targetPriceElement) {
            targetPriceElement.value = defaultTargetPrice;
            console.log(`📊 Set defaultTargetPrice: ${defaultTargetPrice}`);
        }
        
        const commissionElement = document.getElementById('defaultCommission');
        if (commissionElement) {
            commissionElement.value = defaultCommission;
            console.log(`📊 Set defaultCommission: ${defaultCommission}`);
        }
        
        // Color settings - כל הצבעים
        const colorSettings = [
            'primaryColor', 'secondaryColor', 'successColor', 'warningColor',
            'dangerColor', 'infoColor',
            // צבעי ישויות
            'entityTradeColor', 'entityTradeColorLight', 'entityTradeColorDark',
            'entityTradingAccountColor', 'entityTradingAccountColorLight', 'entityTradingAccountColorDark',
            'entityTickerColor', 'entityTickerColorLight', 'entityTickerColorDark',
            'entityAlertColor', 'entityAlertColorLight', 'entityAlertColorDark',
            'entityCashFlowColor', 'entityCashFlowColorLight', 'entityCashFlowColorDark',
            'entityNoteColor', 'entityNoteColorLight', 'entityNoteColorDark',
            'entityExecutionColor', 'entityExecutionColorLight', 'entityExecutionColorDark',
            'entityTradePlanColor', 'entityTradePlanColorLight', 'entityTradePlanColorDark',
            'entityResearchColor', 'entityResearchColorLight', 'entityResearchColorDark',
            'entityPreferencesColor', 'entityPreferencesColorLight', 'entityPreferencesColorDark',
            // צבעי סטטוסים
            'statusOpenColor', 'statusClosedColor', 'statusCancelledColor',
            // צבעי סוגי השקעה
            'typeSwingColor', 'typeInvestmentColor', 'typePassiveColor',
            // צבעי עדיפויות
            'priorityHighColor', 'priorityMediumColor', 'priorityLowColor',
            // צבעי ערכים מספריים
            'valuePositiveColor', 'valueNegativeColor', 'valueNeutralColor',
            // צבעי גרפים
            'chartPrimaryColor', 'chartBackgroundColor', 'chartTextColor',
            'chartPointColor', 'chartGridColor', 'chartBorderColor'
        ];
        
        colorSettings.forEach(setting => {
            const element = document.getElementById(setting);
            if (element && preferences[setting]) {
                element.value = preferences[setting];
            }
        });
        
        console.log('✅ Preferences form populated successfully');
        
        // Update preferences table if function exists
        if (typeof window.updatePreferencesTable === 'function') {
            console.log('📊 Updating preferences table...');
            
            // Convert preferences object to array for table display
            const preferencesArray = Object.entries(preferences).map(([name, value]) => ({
                preference_name: name,
                saved_value: value,
                data_type: typeof value,
                created_at: new Date().toLocaleDateString('he-IL')
            }));
            
            window.updatePreferencesTable(preferencesArray);
            
            // Update table count
            const tableCountElement = document.getElementById('tablePreferencesCount');
            if (tableCountElement) {
                tableCountElement.textContent = preferencesArray.length;
            }
        }
        
    } catch (error) {
        console.error('❌ Error populating preferences form:', error);
    }
};

/**
 * עדכון מונים של ההעדפות
 * @param {Object} preferences - נתוני ההעדפות
 */
window.updatePreferencesCounters = function(preferences) {
    try {
        console.log('📊 Updating preferences counters...');
        
        // Count preferences
        const preferencesCount = Object.keys(preferences).length;
        console.log(`📊 Found ${preferencesCount} preferences to count`);
        
        const preferencesCountElement = document.getElementById('preferencesCount');
        console.log(`📊 preferencesCountElement found:`, preferencesCountElement ? 'YES' : 'NO');
        if (preferencesCountElement) {
            preferencesCountElement.textContent = preferencesCount;
            console.log(`📊 Updated preferences count: ${preferencesCount}`);
        } else {
            console.error('❌ preferencesCountElement not found!');
        }
        
        // Count profiles - get real count from API
        const profilesCountElement = document.getElementById('profilesCount');
        if (profilesCountElement) {
            // Get real profiles count
            if (typeof window.getUserProfiles === 'function') {
                window.getUserProfiles().then(profiles => {
                    const profilesCount = profiles ? profiles.length : 0;
                    profilesCountElement.textContent = profilesCount;
                    console.log(`📊 Updated profiles count: ${profilesCount}`);
                }).catch(error => {
                    console.warn('Error getting profiles count:', error);
                    profilesCountElement.textContent = '1'; // Fallback
                });
            } else {
                profilesCountElement.textContent = '1'; // Fallback
            }
        }
        
        // Count groups - get real count from API
        const groupsCountElement = document.getElementById('groupsCount');
        if (groupsCountElement) {
            // Get real groups count
            fetch('/api/preferences/groups')
                .then(response => response.json())
                .then(result => {
                    const groupsCount = result.data?.groups ? result.data.groups.length : 0;
                    groupsCountElement.textContent = groupsCount;
                    console.log(`📊 Updated groups count: ${groupsCount}`);
                })
                .catch(error => {
                    console.warn('Error getting groups count:', error);
                    groupsCountElement.textContent = '17'; // Fallback
                });
        }
        
        console.log('✅ Preferences counters updated successfully');
        
    } catch (error) {
        console.error('❌ Error updating preferences counters:', error);
    }
};

// ===== EXPORT FOR TESTING =====

// Export functions for testing
// Debug: Verify function is loaded
console.log('🔧 preferences.js loaded - copyDetailedLog function:', typeof copyDetailedLog);

// Profile selection - NO automatic switching, just UI selection
// Profile selection event listener is now handled by the unified initialization system
// Removed duplicate DOMContentLoaded listener to prevent conflicts

/**
 * איסוף נתוני טופס העדפות
 * @returns {Object} - נתוני הטופס
 */
window.collectFormData = function() {
    try {
        console.log('📋 Collecting form data...');
        const formData = {};
        
        // Collect all form elements
        const formElements = document.querySelectorAll('input, select, textarea');
        
        formElements.forEach(element => {
            if (element.id && element.id !== '') {
                if (element.type === 'checkbox') {
                    formData[element.id] = element.checked;
                } else if (element.type === 'color') {
                    formData[element.id] = element.value;
                } else {
                    formData[element.id] = element.value;
                }
            }
        });
        
        console.log(`📋 Collected ${Object.keys(formData).length} form fields`);
        return formData;
        
    } catch (error) {
        console.error('❌ Error collecting form data:', error);
        return {};
    }
};


/**
 * מחיקת פרופיל
 */
window.deleteProfile = async function() {
    try {
        console.log('🗑️ Deleting profile...');
        
        const profileSelect = document.getElementById('profileSelect');
        if (!profileSelect || profileSelect.options.length <= 1) {
            if (typeof window.showErrorNotification === 'function') {
                window.showErrorNotification('שגיאה', 'לא ניתן למחוק את הפרופיל האחרון');
            }
            return false;
        }
        
        const selectedProfile = profileSelect.value;
        if (selectedProfile === 'ברירת מחדל') {
            if (typeof window.showErrorNotification === 'function') {
                window.showErrorNotification('שגיאה', 'לא ניתן למחוק את פרופיל ברירת המחדל');
            }
            return false;
        }
        
        // אישור מחיקה
        if (!confirm(`האם אתה בטוח שברצונך למחוק את הפרופיל "${selectedProfile}"?`)) {
            return false;
        }
        
        // מחיקת הפרופיל מהרשימה
        profileSelect.remove(profileSelect.selectedIndex);
        profileSelect.value = 'ברירת מחדל';
        
        if (typeof window.showSuccessNotification === 'function') {
            window.showSuccessNotification('הצלחה', `פרופיל "${selectedProfile}" נמחק בהצלחה`);
        }
        
        return true;
    } catch (error) {
        console.error('❌ Error deleting profile:', error);
        if (typeof window.showErrorNotification === 'function') {
            window.showErrorNotification('שגיאה', 'שגיאה במחיקת הפרופיל: ' + error.message);
        }
        return false;
    }
};

/**
 * טעינת צבעי ברירת מחדל
 */
window.loadDefaultColors = function() {
    try {
        console.log('🎨 Loading default colors...');
        
        // צבעי מערכת בסיסיים
        const defaultColors = {
            // צבעי מערכת
            primaryColor: '#007bff',
            secondaryColor: '#6c757d', 
            successColor: '#28a745',
            warningColor: '#ffc107',
            dangerColor: '#dc3545',
            infoColor: '#17a2b8',
            
            // צבעי ישויות - Trade Plans (3 וריאנטים)
            entityTradePlanColor: '#007bff',
            entityTradePlanColorLight: '#e3f2fd',
            entityTradePlanColorDark: '#0056b3',
            
            // צבעי ישויות - Trades (3 וריאנטים)
            entityTradeColor: '#28a745',
            entityTradeColorLight: '#e8f5e8',
            entityTradeColorDark: '#1e7e34',
            
            // צבעי ישויות - Alerts (3 וריאנטים)
            entityAlertColor: '#ffc107',
            entityAlertColorLight: '#fff8e1',
            entityAlertColorDark: '#e0a800',
            
            // צבעי ישויות - Notes (3 וריאנטים)
            entityNoteColor: '#6c757d',
            entityNoteColorLight: '#f8f9fa',
            entityNoteColorDark: '#495057',
            
            // צבעי ישויות - Trading Accounts (3 וריאנטים)
            entityTradingAccountColor: '#17a2b8',
            entityTradingAccountColorLight: '#e1f7fa',
            entityTradingAccountColorDark: '#117a8b',
            
            // צבעי ישויות - Tickers (3 וריאנטים)
            entityTickerColor: '#6f42c1',
            entityTickerColorLight: '#f3f0ff',
            entityTickerColorDark: '#5a32a3',
            
            // צבעי ישויות - Executions (3 וריאנטים)
            entityExecutionColor: '#fd7e14',
            entityExecutionColorLight: '#fff4e6',
            entityExecutionColorDark: '#e55a00',
            
            // צבעי ישויות - Trade Plans (3 וריאנטים)
            entityTradePlanColor: '#9c27b0',
            entityTradePlanColorLight: '#ba68c8',
            entityTradePlanColorDark: '#7b1fa2',
            
            // צבעי ישויות - Research (3 וריאנטים)
            entityResearchColor: '#9c27b0',
            entityResearchColorLight: '#ba68c8',
            entityResearchColorDark: '#7b1fa2',
            
            // צבעי ישויות - Preferences (3 וריאנטים)
            entityPreferencesColor: '#607d8b',
            entityPreferencesColorLight: '#90a4ae',
            entityPreferencesColorDark: '#455a64',
            
            // צבעי ישויות - Cash Flows (3 וריאנטים)
            entityCashFlowColor: '#20c997',
            entityCashFlowColorLight: '#e6fcf5',
            entityCashFlowColorDark: '#17a085',
            
            // צבעי סטטוסים (צבע אחד לכל סטטוס)
            statusOpenColor: '#28a745',
            statusClosedColor: '#6c757d',
            statusCancelledColor: '#dc3545',
            
            // צבעי סוגי השקעה (צבע אחד לכל סוג)
            typeSwingColor: '#007bff',
            typeInvestmentColor: '#28a745',
            typePassiveColor: '#6c757d',
            
            // צבעי עדיפויות (צבע אחד לכל עדיפות)
            priorityHighColor: '#dc3545',
            priorityMediumColor: '#ffc107',
            priorityLowColor: '#28a745',
            
            // צבעי ערכים מספריים (צבע אחד לכל סוג)
            valuePositiveColor: '#28a745',
            valueNegativeColor: '#dc3545',
            valueNeutralColor: '#6c757d',
            
            // צבעי גרפים
            chartPrimaryColor: '#007bff',
            chartBackgroundColor: '#ffffff',
            chartTextColor: '#212529',
            chartGridColor: '#dee2e6',
            chartBorderColor: '#dee2e6',
            chartPointColor: '#007bff'
        };
        
        // הגדרת הצבעים בשדות - רק אם השדה ריק
        Object.entries(defaultColors).forEach(([fieldName, colorValue]) => {
            const colorInput = document.getElementById(fieldName);
            if (colorInput && !colorInput.value) {
                colorInput.value = colorValue;
                console.log(`🎨 Set default ${fieldName}: ${colorValue}`);
            }
        });
        
        console.log('✅ Default colors loaded successfully');
        
        // אתחול ניהול שינויים - אחרי טעינת הצבעים
        setTimeout(() => {
            initializeChangeTracking();
        }, 100);
        
        return true;
        
    } catch (error) {
        console.error('❌ Error loading default colors:', error);
        return false;
    }
};

/**
 * אתחול מעקב אחר שינויים
 */
window.initializeChangeTracking = function() {
    try {
        console.log('🔍 Initializing change tracking...');
        
        // שמירת נתוני הטופס המקוריים
        originalFormData = collectFormData();
        
        // הוספת event listeners לכל השדות
        const formElements = document.querySelectorAll('input, select, textarea');
        formElements.forEach(element => {
            if (!element.disabled) {
                element.addEventListener('input', markAsChanged);
                element.addEventListener('change', markAsChanged);
            }
        });
        
        // בדיקת יציאה מהעמוד - רק כאן נבדוק שינויים
        window.addEventListener('beforeunload', function(e) {
            const currentData = collectFormData();
            const hasChanges = JSON.stringify(currentData) !== JSON.stringify(originalFormData);
            
            if (hasChanges) {
                e.preventDefault();
                e.returnValue = 'יש לך שינויים לא שמורים. האם אתה בטוח שברצונך לעזוב?';
                return e.returnValue;
            }
        });
        
        // עדכון מצב הכפתור בהתחלה
        updateSaveButtonState();
        
        console.log('✅ Change tracking initialized');
        
    } catch (error) {
        console.error('❌ Error initializing change tracking:', error);
    }
};

/**
 * ניהול שינויים לא שמורים
 */
let hasUnsavedChanges = false;
let originalFormData = {};

window.markAsChanged = function() {
    hasUnsavedChanges = true;
    updateSaveButtonState();
};

window.markAsSaved = function() {
    hasUnsavedChanges = false;
    originalFormData = collectFormData();
    updateSaveButtonState();
};

window.updateSaveButtonState = function() {
    const saveButton = document.querySelector('button[onclick="saveAllPreferences()"]');
    if (saveButton) {
        if (hasUnsavedChanges) {
            saveButton.classList.remove('btn-success', 'btn-sm');
            saveButton.classList.add('btn-lg');
            saveButton.style.backgroundColor = '#ff9e04'; // כתום הלוגו
            saveButton.style.borderColor = '#ff9e04';
            saveButton.style.color = 'white';
            saveButton.innerHTML = '<i class="fas fa-exclamation-triangle"></i> יש לשמור שינויים';
        } else {
            saveButton.classList.remove('btn-lg');
            saveButton.classList.add('btn-success', 'btn-sm');
            saveButton.style.backgroundColor = '#26baac'; // ירוק הלוגו
            saveButton.style.borderColor = '#26baac';
            saveButton.style.color = 'white';
            saveButton.innerHTML = '<i class="fas fa-save"></i> שמור שינויים';
        }
    }
};


window.confirmExitWithUnsavedChanges = function() {
    // בדיקה רק בנסיון יציאה מהעמוד
    const currentData = collectFormData();
    const hasChanges = JSON.stringify(currentData) !== JSON.stringify(originalFormData);
    
    if (hasChanges) {
        return confirm('יש לך שינויים לא שמורים. האם אתה בטוח שברצונך לעזוב?');
    }
    return true;
};

/**
 * שמירת כל ההעדפות עם ניהול שינויים
 */
window.saveAllPreferences = async function() {
    try {
        console.log('💾 Saving all preferences...');
        
        // הצגת הודעת טעינה
        const saveButton = document.querySelector('button[onclick="saveAllPreferences()"]');
        const originalButtonContent = saveButton.innerHTML;
        saveButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> שומר...';
        saveButton.disabled = true;
        
        const formData = collectFormData();
        console.log('📤 Sending preferences data:', formData);
        
        const success = await savePreferences(formData);
        
        if (success) {
            console.log('✅ Preferences saved successfully');
            
            // ניקוי מטמון באמצעות המערכת המרכזית
            if (window.UnifiedCacheManager && window.UnifiedCacheManager.initialized) {
                await window.UnifiedCacheManager.remove('user-preferences');
                console.log('🗑️ User preferences cache cleared via UnifiedCacheManager');
            }
            
            // רענון העדפות מהשרת
            setTimeout(async () => {
                try {
                    console.log('🔄 Refreshing preferences from server...');
                    
                    // כפיית טעינה מחדש מהשרת
                    const preferences = await window.getAllUserPreferences(1, null, true);
                    if (preferences) {
                        await window.populatePreferencesForm(preferences);
                        window.updatePreferencesCounters(preferences);
                        await window.loadProfilesToDropdown();
                    }
                    
                    // רענון מערכת הצבעים
                    if (window.colorSchemeSystem && window.colorSchemeSystem.loadColorSettings) {
                        window.colorSchemeSystem.loadColorSettings();
                        console.log('🎨 Color system refreshed');
                    }
                    
                    console.log('✅ Preferences refreshed from server');
                    
                } catch (error) {
                    console.error('❌ Error refreshing preferences:', error);
                }
            }, 500);
            
            // הצגת הודעת הצלחה
            if (window.showSuccessNotification) {
                await window.showSuccessNotification('העדפות נשמרו בהצלחה', 'כל ההעדפות נשמרו במערכת', 3000, 'preferences');
            } else if (window.showNotification) {
                await window.showNotification('כל ההעדפות נשמרו במערכת', 'success', 'העדפות נשמרו בהצלחה', 3000, 'preferences');
            } else {
                alert('העדפות נשמרו בהצלחה!');
            }
            
            // סימון כנשמר אחרי הצגת ההודעה
            markAsSaved();
            
            // עדכון כפתור השמירה
            saveButton.innerHTML = '<i class="fas fa-check"></i> נשמר בהצלחה';
            saveButton.classList.remove('btn-lg');
            saveButton.classList.add('btn-success', 'btn-sm');
            saveButton.style.backgroundColor = '#26baac'; // ירוק הלוגו
            saveButton.style.borderColor = '#26baac';
            saveButton.style.color = 'white';
            
            // החזרת הכפתור למצב רגיל אחרי 2 שניות
            setTimeout(() => {
                saveButton.innerHTML = '<i class="fas fa-save"></i> שמור שינויים';
                saveButton.classList.remove('btn-success', 'btn-sm');
                saveButton.classList.add('btn-lg');
                saveButton.style.backgroundColor = '#26baac'; // ירוק הלוגו
                saveButton.style.borderColor = '#26baac';
                saveButton.style.color = 'white';
                saveButton.disabled = false;
            }, 2000);
            
        } else {
            throw new Error('Failed to save preferences - API returned false');
        }
        
    } catch (error) {
        console.error('❌ Error saving all preferences:', error);
        
        // החזרת הכפתור למצב רגיל
        const saveButton = document.querySelector('button[onclick="saveAllPreferences()"]');
        saveButton.innerHTML = '<i class="fas fa-exclamation-triangle"></i> יש לשמור שינויים';
        saveButton.disabled = false;
        saveButton.classList.remove('btn-success', 'btn-sm');
        saveButton.classList.add('btn-lg');
        saveButton.style.backgroundColor = '#ff9e04'; // כתום הלוגו
        saveButton.style.borderColor = '#ff9e04';
        saveButton.style.color = 'white';
        
        // הצגת הודעת שגיאה
        if (window.showErrorNotification) {
            await window.showErrorNotification('שגיאה בשמירת העדפות', 'שגיאה בשמירת ההעדפות: ' + error.message, 5000, 'preferences');
        } else if (window.showNotification) {
            await window.showNotification('שגיאה בשמירת ההעדפות: ' + error.message, 'error', 'שגיאה בשמירת העדפות', 5000, 'preferences');
        } else {
            alert('שגיאה בשמירת ההעדפות: ' + error.message);
        }
    }
};

/**
 * רענון נתוני ניהול
 */
window.refreshAdminData = async function() {
    try {
        console.log('🔄 Refreshing admin data...');
        
        // רענון נתוני משתמשים
        const usersResponse = await fetch('/api/users');
        if (usersResponse.ok) {
            const users = await usersResponse.json();
            const userSelect = document.getElementById('admin-user-select');
            if (userSelect && users.data) {
                userSelect.innerHTML = '';
                users.data.forEach(user => {
                    const option = document.createElement('option');
                    option.value = user.id;
                    option.textContent = user.name || user.username || `משתמש ${user.id}`;
                    if (user.id === 1) option.selected = true;
                    userSelect.appendChild(option);
                });
            }
        }
        
        // רענון נתוני פרופילים
        const profiles = await window.getUserProfiles();
        const profileSelect = document.getElementById('admin-profile-select');
        if (profileSelect && profiles) {
            profileSelect.innerHTML = '<option value="">כל הפרופילים</option>';
            profiles.forEach(profile => {
                const option = document.createElement('option');
                option.value = profile.name;
                option.textContent = profile.name;
                profileSelect.appendChild(option);
            });
        }
        
        // רענון נתוני קבוצות
        const groupsResponse = await fetch('/api/preferences/groups');
        if (groupsResponse.ok) {
            const groups = await groupsResponse.json();
            const groupSelect = document.getElementById('admin-group-select');
            if (groupSelect && groups.data) {
                groupSelect.innerHTML = '<option value="">כל הקבוצות</option>';
                groups.data.forEach(group => {
                    const option = document.createElement('option');
                    option.value = group.name;
                    option.textContent = group.name;
                    groupSelect.appendChild(option);
                });
            }
        }
        
        if (typeof window.showSuccessNotification === 'function') {
            window.showSuccessNotification('הצלחה', 'נתוני הניהול רועננו בהצלחה');
        }
        
        return true;
    } catch (error) {
        console.error('❌ Error refreshing admin data:', error);
        if (typeof window.showErrorNotification === 'function') {
            window.showErrorNotification('שגיאה', 'שגיאה ברענון נתוני הניהול: ' + error.message);
        }
        return false;
    }
};

if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        getPreference: window.getPreference,
        getGroupPreferences: window.getGroupPreferences,
        getPreferencesByNames: window.getPreferencesByNames,
        getAllUserPreferences: window.getAllUserPreferences,
        savePreference: window.savePreference,
        savePreferences: window.savePreferences,
        getUserProfiles: window.getUserProfiles,
        clearPreferencesCache: window.clearPreferencesCache,
        checkPreferencesServiceHealth: window.checkPreferencesServiceHealth,
        getPreferenceInfo: window.getPreferenceInfo,
        loadPreferences: window.loadPreferences,
        loadAllPreferences: window.loadAllPreferences,
        saveAllPreferences: window.saveAllPreferences,
        resetToDefaults: window.resetToDefaults,
        initializePreferences: window.initializePreferences,
        copyPreferencesDetailedLog: window.copyPreferencesDetailedLog,
        copyDetailedLog: copyDetailedLog,
        populatePreferencesForm: window.populatePreferencesForm,
        updatePreferencesCounters: window.updatePreferencesCounters,
        saveAsActiveProfile: window.saveAsActiveProfile,
        deleteProfile: window.deleteProfile,
        refreshAdminData: window.refreshAdminData,
        loadDefaultColors: window.loadDefaultColors,
        collectFormData: window.collectFormData,
        markAsChanged: window.markAsChanged,
        markAsSaved: window.markAsSaved,
        confirmExitWithUnsavedChanges: window.confirmExitWithUnsavedChanges,
        initializeChangeTracking: window.initializeChangeTracking
    };
}
